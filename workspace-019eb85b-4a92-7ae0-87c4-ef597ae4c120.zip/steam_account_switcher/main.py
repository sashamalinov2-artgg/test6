"""Steam Account Switcher — GUI для быстрого логина в Steam-аккаунты.

Хранит логин/пароль/путь к mafile в accounts.json рядом с main.py.
Steam Guard код берётся из mafile (TOTP) по умолчанию.
Каждый аккаунт логинится в свой профиль Chrome чтобы сессии не конфликтовали.

Поддерживает импорт из logpass.txt (login:password, по одной паре на строку).
Папка mafiles/ рядом с main.py — программа сама найдёт .maFile по логину.

Фарм: цветовые теги (queued=жёлтый, active=зелёный, done=фиолетовый),
live-счётчик, удаление нескольких, scrollbar.
"""

import json
import os
import subprocess
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from logger import logger, log_exc
from mafile import code_from_mafile, seconds_until_next_code
from steam_browser import _is_window_closed_error, login, make_driver
from steam_client import find_steam_exe, login_steam_client, force_kill_all_steam, shutdown_steam
from logpass_parser import parse_logpass, DEFAULT_MAFILES_DIR


BASE_DIR = Path(__file__).parent
CONFIG_PATH = BASE_DIR / "accounts.json"


def load_config():
    if not CONFIG_PATH.exists():
        default = {
            "accounts": [],
            "settings": {
                "chrome_profiles_dir": "chrome_profiles",
                "mafiles_dir": str(DEFAULT_MAFILES_DIR.relative_to(BASE_DIR)),
                "steam_exe_path": "",
                "post_start_delay": 5.0,
                "post_login_delay": 5.0,
                "default_appid": "",
                "save_steam_sessions": False,
                "steam_sessions_dir": "steam_sessions",
            },
        }
        logger.info("accounts.json не найден, создана пустая конфигурация")
        return default
    try:
        text = CONFIG_PATH.read_text(encoding="utf-8")
        logger.info("Загружена конфигурация, %s байт", len(text))
        return json.loads(text)
    except PermissionError as e:
        logger.error("Permission denied при чтении accounts.json: %s", e)
        raise
    except Exception as e:
        log_exc("Ошибка загрузки accounts.json", e)
        raise


def save_config(config):
    try:
        text = json.dumps(config, indent=2, ensure_ascii=False)
        CONFIG_PATH.write_text(text, encoding="utf-8")
        logger.info("Конфигурация сохранена (%s байт)", len(text))
    except PermissionError as e:
        logger.error("Permission denied при записи accounts.json: %s", e)
        raise
    except Exception as e:
        log_exc("Ошибка сохранения accounts.json", e)
        raise


def _find_mafile(mafiles_dir: str, login: str, label: str) -> str:
    """Ищет .maFile в папке mafiles_dir по имени аккаунта или логину."""
    if not mafiles_dir:
        mafiles_dir = str(DEFAULT_MAFILES_DIR.relative_to(BASE_DIR))
    d = Path(mafiles_dir)
    if not d.is_absolute():
        d = BASE_DIR / d
    if not d.exists():
        logger.warning("Папка mafiles не найдена: %s", d)
        return None

    candidates = [
        d / f"{login}.maFile",
        d / f"{login}.mafile",
        d / f"{label}.maFile",
        d / f"{label}.mafile",
    ]
    for c in candidates:
        if c.exists():
            try:
                rel = c.relative_to(BASE_DIR)
                return str(rel).replace("\\", "/")
            except ValueError:
                return str(c)

    files = list(d.glob("*.maFile")) + list(d.glob("*.mafile"))
    if len(files) == 1:
        try:
            rel = files[0].relative_to(BASE_DIR)
            return str(rel).replace("\\", "/")
        except ValueError:
            return str(files[0])

    logger.warning("mafile не найден для %s / %s в %s", login, label, d)
    return None


class App:
    def __init__(self, root):
        self.root = root
        root.title("Steam Account Switcher")
        root.geometry("1100x650")
        self.config = load_config()
        self._active_drivers = []
        self._farm_stop = False
        self._farm_thread = None

        logger.info("GUI инициализируется")

        main = ttk.Frame(root, padding=10)
        main.pack(fill="both", expand=True)

        # --- Счётчик фарма (вверху) ---
        self.farm_counter = ttk.Label(
            main, text="Готов", anchor="center", padding=5,
            font=("Segoe UI", 10, "bold")
        )
        self.farm_counter.pack(fill="x", side="top", pady=(0, 5))

        # --- Treeview со scrollbar ---
        tree_frame = ttk.Frame(main)
        tree_frame.pack(fill="both", expand=True, side="top")

        cols = ("label", "login", "mafile", "appid")
        self.tree = ttk.Treeview(
            tree_frame, columns=cols, show="headings", height=14,
            selectmode="extended"
        )
        self.tree.heading("label", text="Название")
        self.tree.heading("login", text="Логин")
        self.tree.heading("mafile", text="mafile")
        self.tree.heading("appid", text="AppID")
        self.tree.column("label", width=180)
        self.tree.column("login", width=180)
        self.tree.column("mafile", width=350)
        self.tree.column("appid", width=120, anchor="center")
        self.tree.pack(side="left", fill="both", expand=True)

        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")

        self.tree.bind("<Double-1>", lambda e: self.login_selected())

        # Цветовые теги
        self.tree.tag_configure("queued", background="#fff59d")
        self.tree.tag_configure("active", background="#a5d6a7")
        self.tree.tag_configure("done", background="#ce93d8")

        # --- Блок: Вход ---
        frame_login = ttk.LabelFrame(root, text="Вход", padding=5)
        frame_login.pack(fill="x", padx=10, pady=2)
        ttk.Button(frame_login, text="Войти (браузер)", command=self.login_selected).pack(side="left", padx=3)
        ttk.Button(frame_login, text="Войти в клиент", command=self.login_client_selected).pack(side="left", padx=3)

        # --- Блок: Игра ---
        frame_game = ttk.LabelFrame(root, text="Игра", padding=5)
        frame_game.pack(fill="x", padx=10, pady=2)
        ttk.Button(frame_game, text="Запустить игру", command=self.launch_game_selected).pack(side="left", padx=3)
        ttk.Button(frame_game, text="Farm", command=self.farm_selected).pack(side="left", padx=3)
        ttk.Button(frame_game, text="Остановить фарм", command=self.stop_farm).pack(side="left", padx=3)

        # --- Блок: Steam ---
        frame_steam = ttk.LabelFrame(root, text="Steam", padding=5)
        frame_steam.pack(fill="x", padx=10, pady=2)
        ttk.Button(frame_steam, text="Kill Steam", command=self.kill_steam).pack(side="left", padx=3)

        # --- Блок: Аккаунты ---
        frame_acc = ttk.LabelFrame(root, text="Аккаунты", padding=5)
        frame_acc.pack(fill="x", padx=10, pady=2)
        ttk.Button(frame_acc, text="Импорт logpass", command=self.import_logpass).pack(side="left", padx=3)
        ttk.Button(frame_acc, text="Добавить", command=self.add_account).pack(side="left", padx=3)
        ttk.Button(frame_acc, text="Изменить", command=self.edit_account).pack(side="left", padx=3)
        ttk.Button(frame_acc, text="Удалить", command=self.delete_account).pack(side="left", padx=3)
        ttk.Button(frame_acc, text="Выбрать все", command=self.select_all).pack(side="left", padx=3)
        ttk.Button(frame_acc, text="Применить AppID", command=self.apply_appid_all).pack(side="left", padx=3)

        # --- Блок: Система ---
        frame_sys = ttk.LabelFrame(root, text="Система", padding=5)
        frame_sys.pack(fill="x", padx=10, pady=2)
        ttk.Button(frame_sys, text="Настройки", command=self.open_settings).pack(side="left", padx=3)
        ttk.Button(frame_sys, text="Обновить", command=self.refresh).pack(side="left", padx=3)

        self.status = ttk.Label(root, text="Готов", anchor="w", padding=5, relief="sunken")
        self.status.pack(fill="x", side="bottom")

        self.refresh()

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        self.config = load_config()
        for i, acc in enumerate(self.config.get("accounts", [])):
            self.tree.insert(
                "",
                "end",
                iid=str(i),
                values=(
                    acc.get("label", ""),
                    acc.get("login", ""),
                    acc.get("mafile", "") or "—",
                    acc.get("appid") or "—",
                ),
            )
        logger.info("Список аккаунтов обновлён: %s записей", len(self.config.get("accounts", [])))

    def select_all(self):
        for item in self.tree.get_children():
            self.tree.selection_add(item)
        logger.info("Выбраны все аккаунты")

    def get_selected_indices(self):
        sel = self.tree.selection()
        if not sel:
            return []
        return sorted([int(self.tree.index(item)) for item in sel])

    def get_selected(self):
        indices = self.get_selected_indices()
        if not indices:
            return None
        return self.config["accounts"][indices[0]]

    def get_selected_accounts(self):
        indices = self.get_selected_indices()
        return [self.config["accounts"][i] for i in indices]

    def set_status(self, text):
        logger.info("[STATUS] %s", text)
        self.status.config(text=text)
        self.root.update_idletasks()

    def _update_farm_counter(self, current, total):
        text = f"Farm: {current} / {total}"
        self.farm_counter.config(text=text)
        self.root.update_idletasks()

    def _reset_farm_counter(self):
        self.farm_counter.config(text="Готов")

    def _set_row_tag(self, idx, tag):
        try:
            self.tree.item(str(idx), tags=(tag,))
        except Exception:
            pass

    def _clear_all_tags(self):
        for item in self.tree.get_children():
            try:
                self.tree.item(item, tags=())
            except Exception:
                pass

    def stop_farm(self):
        if self._farm_thread and self._farm_thread.is_alive():
            self._farm_stop = True
            self.set_status("Остановка фарма... (дождись завершения текущего шага)")
            logger.info("Запрошена остановка фарма")
        else:
            self.set_status("Фарм не запущен")

    def apply_appid_all(self):
        appid = self.config.get("settings", {}).get("default_appid", "").strip()
        if not appid:
            messagebox.showwarning(
                "AppID не задан",
                "Глобальный AppID не настроен.\n"
                "Открой 'Настройки' → 'Игра' и укажи 'AppID по умолчанию',\n"
                "потом нажми 'Применить AppID'."
            )
            return
        accounts = self.config.get("accounts", [])
        if not accounts:
            messagebox.showwarning("Внимание", "Нет аккаунтов для обновления")
            return
        for acc in accounts:
            acc["appid"] = appid
        save_config(self.config)
        self.refresh()
        self.set_status(f"AppID {appid} применён ко всем {len(accounts)} аккаунтам")
        logger.info("Глобальный AppID %s применён ко всем аккаунтам", appid)

    # ---- Account actions ----

    def login_selected(self):
        acc = self.get_selected()
        if not acc:
            messagebox.showwarning("Внимание", "Выбери аккаунт в списке")
            return
        logger.info("Запрошен вход (браузер) для '%s'", acc.get("label"))
        threading.Thread(target=self._do_login, args=(acc,), daemon=True).start()

    def login_client_selected(self):
        acc = self.get_selected()
        if not acc:
            messagebox.showwarning("Внимание", "Выбери аккаунт в списке")
            return
        logger.info("Запрошен вход (клиент Steam) для '%s'", acc.get("label"))
        threading.Thread(target=self._do_login_client, args=(acc,), daemon=True).start()

    def launch_game_selected(self):
        acc = self.get_selected()
        if not acc:
            messagebox.showwarning("Внимание", "Выбери аккаунт в списке")
            return
        appid = acc.get("appid", "").strip()
        if not appid:
            messagebox.showwarning("Внимание", "У этого аккаунта не указан AppID. Открой 'Настройки' и укажи 'AppID по умолчанию', затем нажми 'Применить AppID'.")
            return
        logger.info("Запрошен запуск игры AppID=%s для '%s'", appid, acc.get("label"))
        threading.Thread(target=self._do_launch_game, args=(acc, appid), daemon=True).start()

    def kill_steam(self):
        logger.info("Запрошен Kill Steam")
        threading.Thread(target=self._do_kill_steam, daemon=True).start()

    def _do_kill_steam(self):
        try:
            self.set_status("Убиваю все процессы Steam...")
            ok = force_kill_all_steam()
            if ok:
                self.set_status("Все процессы Steam закрыты")
            else:
                self.set_status("Не удалось закрыть некоторые процессы Steam")
        except Exception as e:
            log_exc("Ошибка Kill Steam", e)
            self.set_status(f"Ошибка: {e}")
            messagebox.showerror("Ошибка", str(e))

    def import_logpass(self):
        logpass_path = BASE_DIR / "logpass.txt"
        if not logpass_path.exists():
            messagebox.showwarning(
                "logpass.txt не найден",
                f"Создай файл logpass.txt в папке программы:\n{BASE_DIR}\n\n"
                f"Формат:\nlogin1:password1\nlogin2:password2\n..."
            )
            return

        try:
            mafiles_dir = self.config.get("settings", {}).get("mafiles_dir", "")
            if not mafiles_dir:
                mafiles_dir = str(DEFAULT_MAFILES_DIR.relative_to(BASE_DIR))
            d = Path(mafiles_dir)
            if not d.is_absolute():
                d = BASE_DIR / d

            accounts = parse_logpass(path=logpass_path, mafiles_dir=d)
            if not accounts:
                messagebox.showinfo("Импорт", "В logpass.txt не найдено валидных записей.")
                return

            default_appid = self.config.get("settings", {}).get("default_appid", "").strip()

            existing_logins = {a["login"] for a in self.config.get("accounts", [])}
            added = 0
            skipped = 0
            for acc in accounts:
                if acc["login"] in existing_logins:
                    skipped += 1
                    continue
                if default_appid:
                    acc["appid"] = default_appid
                self.config.setdefault("accounts", []).append(acc)
                existing_logins.add(acc["login"])
                added += 1

            save_config(self.config)
            self.refresh()
            msg = f"Добавлено: {added}\nПропущено (дубликаты): {skipped}"
            if default_appid:
                msg += f"\nAppID {default_appid} применён к новым аккаунтам"
            logger.info("Импорт из logpass.txt: %s", msg)
            messagebox.showinfo("Импорт завершён", msg)
        except Exception as e:
            log_exc("Ошибка импорта logpass.txt", e)
            messagebox.showerror("Ошибка импорта", str(e))

    def farm_selected(self):
        indices = self.get_selected_indices()
        accounts = [self.config["accounts"][i] for i in indices]
        if not accounts:
            messagebox.showwarning("Внимание", "Выбери хотя бы один аккаунт (Ctrl/Shift + клик)")
            return
        FarmDialog(self.root, accounts, indices, self.config, on_start=self._do_farm)

    def _do_farm(self, accounts, indices, post_start_delay, post_login_delay, game_time, launch_game, close_steam, run_browser):
        self._farm_stop = False
        total = len(accounts)
        steam_exe = find_steam_exe(self.config.get("settings", {}).get("steam_exe_path"))
        save_session = self.config.get("settings", {}).get("save_steam_sessions", False)
        session_dir = self.config.get("settings", {}).get("steam_sessions_dir", "steam_sessions")

        self._clear_all_tags()
        for idx in indices:
            self._set_row_tag(idx, "queued")
        self._update_farm_counter(0, total)

        for i, (acc, idx) in enumerate(zip(accounts, indices)):
            if self._farm_stop:
                self.set_status("Farm остановлен пользователем")
                break

            if i > 0:
                self._set_row_tag(indices[i - 1], "done")
            self._set_row_tag(idx, "active")
            self._update_farm_counter(i + 1, total)

            self.set_status(f"[{acc['label']}] ({i+1}/{total}) вход...")
            try:
                get_code = self._build_get_code(acc)

                if run_browser:
                    profiles_root = self.config.get("settings", {}).get("chrome_profiles_dir", "chrome_profiles")
                    profile = BASE_DIR / profiles_root / _safe_filename(acc["label"])
                    driver = make_driver(profile_dir=str(profile))
                    self._active_drivers.append(driver)
                    login(
                        driver, acc["login"], acc["password"], get_code,
                        status_callback=lambda t: self.set_status(f"[{acc['label']}] {t}"),
                    )
                else:
                    if not steam_exe:
                        raise FileNotFoundError("steam.exe не найден")
                    login_steam_client(
                        steam_exe, acc["login"], acc["password"], get_code,
                        status_callback=lambda t: self.set_status(f"[{acc['label']}] {t}"),
                        post_start_delay=post_start_delay,
                        save_session=save_session,
                        session_backup_dir=session_dir,
                    )
            except Exception as e:
                log_exc(f"Ошибка входа для '{acc.get('label', '?')}'", e)
                self.set_status(f"Ошибка {acc['label']}: {e}")
                continue

            if self._farm_stop:
                break
            if post_login_delay > 0:
                self.set_status(f"[{acc['label']}] жду {post_login_delay}с перед запуском игры...")
                for _ in range(int(post_login_delay)):
                    if self._farm_stop:
                        break
                    time.sleep(1)
                if self._farm_stop:
                    break

            if launch_game and acc.get("appid"):
                self.set_status(f"[{acc['label']}] запуск игры...")
                try:
                    self._do_launch_game_sync(acc, acc["appid"])
                except Exception as e:
                    log_exc(f"Ошибка запуска игры для '{acc['label']}'", e)

            if self._farm_stop:
                break
            if game_time > 0:
                self.set_status(f"[{acc['label']}] играем {game_time}с...")
                for _ in range(int(game_time)):
                    if self._farm_stop:
                        break
                    time.sleep(1)
                if self._farm_stop:
                    break

            if close_steam and steam_exe:
                self.set_status(f"[{acc['label']}] закрываю Steam...")
                try:
                    shutdown_steam(steam_exe)
                except Exception as e:
                    logger.warning("Не удалось корректно закрыть Steam: %s", e)
                    force_kill_all_steam()
                time.sleep(2)

        if indices and total > 0:
            self._set_row_tag(indices[total - 1], "done")

        self._farm_stop = False
        self._farm_thread = None
        self._reset_farm_counter()
        self.set_status("Farm завершён")

    def _build_get_code(self, acc):
        mafile_path = acc.get("mafile")
        if not mafile_path:
            mafiles_dir = self.config.get("settings", {}).get("mafiles_dir", "")
            if not mafiles_dir:
                mafiles_dir = str(DEFAULT_MAFILES_DIR.relative_to(BASE_DIR))
            if mafiles_dir:
                mafile_path = _find_mafile(mafiles_dir, acc.get("login", ""), acc.get("label", ""))
                if mafile_path:
                    logger.info("Автоматически найден mafile: %s", mafile_path)

        if not mafile_path:
            raise ValueError("mafile не найден. Укажи путь к .maFile или проверь папку mafiles.")

        full_path = mafile_path if Path(mafile_path).is_absolute() else BASE_DIR / mafile_path
        if not Path(full_path).exists():
            raise FileNotFoundError(f"mafile не найден: {full_path}")

        def get_code():
            secs = seconds_until_next_code()
            if secs < 5:
                self.set_status(f"[{acc['label']}] жду свежий код ({secs}с)...")
                logger.info("Жду обновления TOTP (осталось %s сек)", secs)
                time.sleep(secs + 1)
            code = code_from_mafile(full_path)
            logger.info("Сгенерирован TOTP-код для '%s'", acc["label"])
            return code

        return get_code

    def _do_login(self, acc):
        try:
            self.set_status(f"[{acc['label']}] подготовка...")
            get_code = self._build_get_code(acc)

            profiles_root = self.config.get("settings", {}).get("chrome_profiles_dir", "chrome_profiles")
            profile = BASE_DIR / profiles_root / _safe_filename(acc["label"])
            logger.info("Профиль Chrome: %s", profile)

            self.set_status(f"[{acc['label']}] запускаю Chrome...")
            driver = make_driver(profile_dir=str(profile))
            self._active_drivers.append(driver)
            logger.info("Chrome запущен, driver создан")

            login(
                driver,
                acc["login"],
                acc["password"],
                get_code,
                status_callback=lambda t: self.set_status(f"[{acc['label']}] {t}"),
            )
            self.set_status(f"[{acc['label']}] готово")
            logger.info("Браузерный вход для '%s' завершён", acc["label"])
        except Exception as e:
            if _is_window_closed_error(e):
                self.set_status(f"[{acc['label']}] окно браузера закрыто")
                logger.info("Окно браузера закрыто пользователем для '%s'", acc["label"])
                return
            log_exc(f"Ошибка браузерного входа для '{acc.get('label', '?')}'", e)
            self.set_status(f"Ошибка: {e}")
            messagebox.showerror("Ошибка", f"{acc.get('label','?')}: {e}")

    def _do_login_client(self, acc):
        try:
            self.set_status(f"[{acc['label']}] подготовка (клиент Steam)...")
            steam_exe = find_steam_exe(
                self.config.get("settings", {}).get("steam_exe_path")
            )
            if not steam_exe:
                raise FileNotFoundError(
                    "steam.exe не найден. Укажи путь к Steam в Настройках."
                )
            logger.info("steam.exe найден: %s", steam_exe)

            get_code = self._build_get_code(acc)
            post_start = self.config.get("settings", {}).get("post_start_delay", 5.0)
            save_session = self.config.get("settings", {}).get("save_steam_sessions", False)
            session_dir = self.config.get("settings", {}).get("steam_sessions_dir", "steam_sessions")

            login_steam_client(
                steam_exe,
                acc["login"],
                acc["password"],
                get_code,
                status_callback=lambda t: self.set_status(f"[{acc['label']}] {t}"),
                post_start_delay=post_start,
                save_session=save_session,
                session_backup_dir=session_dir,
            )
            self.set_status(f"[{acc['label']}] вход в клиент завершён")
            logger.info("Вход в клиент Steam для '%s' завершён", acc["label"])
        except Exception as e:
            log_exc(f"Ошибка входа в клиент Steam для '{acc.get('label', '?')}'", e)
            self.set_status(f"Ошибка: {e}")
            messagebox.showerror("Ошибка", f"{acc.get('label','?')}: {e}")

    def _do_launch_game(self, acc, appid):
        try:
            self.set_status(f"[{acc['label']}] запускаю игру (AppID {appid})...")
            self._do_launch_game_sync(acc, appid)
            self.set_status(f"[{acc['label']}] игра запущена (AppID {appid})")
        except Exception as e:
            log_exc(f"Ошибка запуска игры для '{acc.get('label', '?')}'", e)
            self.set_status(f"Ошибка запуска игры: {e}")
            messagebox.showerror("Ошибка", f"{acc.get('label','?')}: {e}")

    def _do_launch_game_sync(self, acc, appid):
        steam_url = f"steam://rungameid/{appid}"
        if os.name == "nt" and hasattr(os, "startfile"):
            os.startfile(steam_url)
            logger.info("Игра запущена через os.startfile: %s", steam_url)
        else:
            subprocess.Popen(["xdg-open", steam_url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            logger.info("Игра запущена через xdg-open: %s", steam_url)

    def add_account(self):
        AccountDialog(self.root, on_save=self._on_account_saved, mafiles_dir=self.config.get("settings", {}).get("mafiles_dir", ""))

    def edit_account(self):
        idx = self.get_selected_indices()
        if not idx:
            messagebox.showwarning("Внимание", "Выбери аккаунт")
            return
        AccountDialog(
            self.root,
            on_save=lambda data: self._on_account_saved(data, replace_index=idx[0]),
            initial=self.config["accounts"][idx[0]],
            mafiles_dir=self.config.get("settings", {}).get("mafiles_dir", ""),
        )

    def _on_account_saved(self, data, replace_index=None):
        if replace_index is None:
            self.config.setdefault("accounts", []).append(data)
            logger.info("Добавлен аккаунт '%s'", data.get("label"))
        else:
            old_label = self.config["accounts"][replace_index].get("label")
            self.config["accounts"][replace_index] = data
            logger.info("Изменён аккаунт '%s' -> '%s'", old_label, data.get("label"))
        save_config(self.config)
        self.refresh()

    def delete_account(self):
        indices = self.get_selected_indices()
        if not indices:
            return
        count = len(indices)
        noun = "аккаунт" if count == 1 else "аккаунта" if count < 5 else "аккаунтов"
        if messagebox.askyesno("Удалить", f"Удалить {count} {noun}?"):
            for idx in reversed(indices):
                acc = self.config["accounts"][idx]
                logger.info("Удалён аккаунт '%s'", acc["label"])
                del self.config["accounts"][idx]
            save_config(self.config)
            self.refresh()

    def open_settings(self):
        SettingsDialog(self.root, self.config, on_save=self._on_settings_saved)

    def _on_settings_saved(self, settings):
        self.config["settings"] = settings
        save_config(self.config)
        self.set_status("Настройки сохранены")
        logger.info("Настройки сохранены: %s", settings)


class AccountDialog:
    def __init__(self, parent, on_save, mafiles_dir="", initial=None):
        self.on_save = on_save
        self.mafiles_dir = mafiles_dir

        win = tk.Toplevel(parent)
        win.title("Аккаунт")
        win.geometry("520x400")
        win.transient(parent)
        win.grab_set()
        self.win = win

        initial = initial or {}

        def add_row(row, label, widget):
            ttk.Label(win, text=label).grid(row=row, column=0, sticky="w", padx=10, pady=6)
            widget.grid(row=row, column=1, padx=10, pady=6, sticky="ew")

        win.columnconfigure(1, weight=1)

        self.label_var = tk.StringVar(value=initial.get("label", ""))
        add_row(0, "Название:", ttk.Entry(win, textvariable=self.label_var))

        self.login_var = tk.StringVar(value=initial.get("login", ""))
        add_row(1, "Логин Steam:", ttk.Entry(win, textvariable=self.login_var))
        self.login_var.trace_add("write", self._on_login_change)

        self.password_var = tk.StringVar(value=initial.get("password", ""))
        pwd_entry = ttk.Entry(win, textvariable=self.password_var, show="*")
        add_row(2, "Пароль:", pwd_entry)

        # mafile с кнопкой обзора
        mafile_frame = ttk.Frame(win)
        self.mafile_var = tk.StringVar(value=initial.get("mafile") or "")
        ttk.Entry(mafile_frame, textvariable=self.mafile_var).pack(side="left", fill="x", expand=True)
        ttk.Button(mafile_frame, text="...", command=self._browse_mafile, width=3).pack(side="left", padx=3)
        ttk.Button(mafile_frame, text="Авто", command=self._auto_find_mafile, width=4).pack(side="left", padx=2)
        add_row(3, "Путь к .maFile:", mafile_frame)

        self.appid_var = tk.StringVar(value=initial.get("appid") or "")
        add_row(4, "AppID игры:", ttk.Entry(win, textvariable=self.appid_var))

        hint = ttk.Label(
            win,
            text=(
                "Код генерируется автоматически из mafile.\n"
                "AppID — цифровой ID игры в Steam (например, 730 для CS2).\n"
                "Кнопка 'Авто' — ищет .maFile в папке mafiles по имени логина."
            ),
            foreground="gray",
            justify="left",
        )
        hint.grid(row=5, column=0, columnspan=2, padx=10, pady=5, sticky="w")

        btns = ttk.Frame(win)
        btns.grid(row=6, column=0, columnspan=2, pady=15)
        ttk.Button(btns, text="Сохранить", command=self._save).pack(side="left", padx=5)
        ttk.Button(btns, text="Отмена", command=win.destroy).pack(side="left", padx=5)

    def _on_login_change(self, *args):
        if self.mafile_var.get() or not self.mafiles_dir:
            return
        path = _find_mafile(self.mafiles_dir, self.login_var.get(), self.label_var.get())
        if path:
            self.mafile_var.set(path)

    def _browse_mafile(self):
        path = filedialog.askopenfilename(
            title="Выбери .maFile",
            filetypes=[("Steam mobile authenticator", "*.maFile *.mafile"), ("Все файлы", "*.*")],
            parent=self.win,
        )
        if not path:
            return
        try:
            rel = Path(path).relative_to(BASE_DIR)
            self.mafile_var.set(str(rel).replace("\\", "/"))
        except ValueError:
            self.mafile_var.set(path)

    def _auto_find_mafile(self):
        if not self.mafiles_dir:
            messagebox.showwarning("Внимание", "Папка mafiles не настроена. Открой 'Настройки' и укажи путь.", parent=self.win)
            return
        path = _find_mafile(self.mafiles_dir, self.login_var.get(), self.label_var.get())
        if path:
            self.mafile_var.set(path)
            messagebox.showinfo("Найдено", f"Найден .maFile:\n{path}", parent=self.win)
        else:
            messagebox.showwarning("Не найдено", ".maFile не найден в папке mafiles", parent=self.win)

    def _save(self):
        if not self.label_var.get().strip():
            messagebox.showwarning("Внимание", "Введи название", parent=self.win)
            return
        if not self.login_var.get().strip():
            messagebox.showwarning("Внимание", "Введи логин Steam", parent=self.win)
            return
        data = {
            "label": self.label_var.get().strip(),
            "login": self.login_var.get().strip(),
            "password": self.password_var.get(),
            "mafile": self.mafile_var.get().strip() or None,
            "guard_source": "mafile",
            "nebula_account_name": None,
            "appid": self.appid_var.get().strip() or None,
        }
        self.on_save(data)
        self.win.destroy()


class SettingsDialog:
    def __init__(self, parent, config, on_save):
        self.on_save = on_save
        settings = config.get("settings", {})

        win = tk.Toplevel(parent)
        win.title("Настройки")
        win.geometry("560x540")
        win.transient(parent)
        win.grab_set()
        self.win = win

        win.columnconfigure(1, weight=1)

        row = 0

        # --- Папки ---
        ttk.Label(win, text="Папки", font=("", 9, "bold")).grid(row=row, column=0, sticky="w", padx=10, pady=(10, 2))
        row += 1

        ttk.Label(win, text="Папка профилей Chrome:").grid(row=row, column=0, sticky="w", padx=10, pady=2)
        self.profiles_var = tk.StringVar(value=settings.get("chrome_profiles_dir", "chrome_profiles"))
        ttk.Entry(win, textvariable=self.profiles_var).grid(row=row, column=1, padx=10, pady=2, sticky="ew")
        row += 1

        ttk.Label(win, text="Папка mafiles:").grid(row=row, column=0, sticky="w", padx=10, pady=2)
        mafiles_frame = ttk.Frame(win)
        self.mafiles_var = tk.StringVar(value=settings.get("mafiles_dir", str(DEFAULT_MAFILES_DIR.relative_to(BASE_DIR))))
        ttk.Entry(mafiles_frame, textvariable=self.mafiles_var).pack(side="left", fill="x", expand=True)
        ttk.Button(mafiles_frame, text="...", command=self._browse_mafiles, width=3).pack(side="left", padx=3)
        mafiles_frame.grid(row=row, column=1, padx=10, pady=2, sticky="ew")
        row += 1

        ttk.Separator(win, orient="horizontal").grid(row=row, column=0, columnspan=2, sticky="ew", pady=10)
        row += 1

        # --- Задержки ---
        ttk.Label(win, text="Задержки (секунды)", font=("", 9, "bold")).grid(row=row, column=0, sticky="w", padx=10, pady=2)
        row += 1

        ttk.Label(win, text="Ждём Steam после запуска:").grid(row=row, column=0, sticky="w", padx=10, pady=2)
        self.post_start_var = tk.StringVar(value=str(settings.get("post_start_delay", 5.0)))
        ttk.Entry(win, textvariable=self.post_start_var, width=10).grid(row=row, column=1, sticky="w", padx=10, pady=2)
        row += 1

        ttk.Label(win, text="Ждём после входа перед игрой:").grid(row=row, column=0, sticky="w", padx=10, pady=2)
        self.post_login_var = tk.StringVar(value=str(settings.get("post_login_delay", 5.0)))
        ttk.Entry(win, textvariable=self.post_login_var, width=10).grid(row=row, column=1, sticky="w", padx=10, pady=2)
        row += 1

        ttk.Separator(win, orient="horizontal").grid(row=row, column=0, columnspan=2, sticky="ew", pady=10)
        row += 1

        # --- Игра ---
        ttk.Label(win, text="Игра", font=("", 9, "bold")).grid(row=row, column=0, sticky="w", padx=10, pady=2)
        row += 1

        ttk.Label(win, text="AppID по умолчанию (для всех аккаунтов):").grid(row=row, column=0, sticky="w", padx=10, pady=2)
        self.default_appid_var = tk.StringVar(value=str(settings.get("default_appid", "")))
        ttk.Entry(win, textvariable=self.default_appid_var, width=15).grid(row=row, column=1, sticky="w", padx=10, pady=2)
        row += 1

        ttk.Separator(win, orient="horizontal").grid(row=row, column=0, columnspan=2, sticky="ew", pady=10)
        row += 1

        # --- Сессии Steam ---
        ttk.Label(win, text="Сессии Steam", font=("", 9, "bold")).grid(row=row, column=0, sticky="w", padx=10, pady=2)
        row += 1

        self.save_session_var = tk.BooleanVar(value=settings.get("save_steam_sessions", False))
        ttk.Checkbutton(win, text="Сохранять сессии Steam (вход без пароля, если сессия жива)", variable=self.save_session_var).grid(row=row, column=0, columnspan=2, sticky="w", padx=10, pady=2)
        row += 1

        ttk.Label(win, text="Папка сессий:").grid(row=row, column=0, sticky="w", padx=10, pady=2)
        self.sessions_dir_var = tk.StringVar(value=settings.get("steam_sessions_dir", "steam_sessions"))
        ttk.Entry(win, textvariable=self.sessions_dir_var).grid(row=row, column=1, padx=10, pady=2, sticky="ew")
        row += 1

        ttk.Separator(win, orient="horizontal").grid(row=row, column=0, columnspan=2, sticky="ew", pady=10)
        row += 1

        # --- Steam ---
        ttk.Label(win, text="Steam", font=("", 9, "bold")).grid(row=row, column=0, sticky="w", padx=10, pady=2)
        row += 1

        ttk.Label(win, text="Путь к steam.exe:").grid(row=row, column=0, sticky="w", padx=10, pady=2)
        steam_frame = ttk.Frame(win)
        self.steam_var = tk.StringVar(value=settings.get("steam_exe_path", ""))
        ttk.Entry(steam_frame, textvariable=self.steam_var).pack(side="left", fill="x", expand=True)
        ttk.Button(steam_frame, text="...", command=self._browse_steam, width=3).pack(side="left", padx=3)
        steam_frame.grid(row=row, column=1, padx=10, pady=2, sticky="ew")
        row += 1

        hint = ttk.Label(
            win,
            text="Папка mafiles — по умолчанию 'mafiles' рядом с программой.\n"
                 "AppID по умолчанию — при импорте и кнопке 'Применить AppID' устанавливается всем.\n"
                 "Сессии Steam — бэкапят config.vdf, loginusers.vdf и ssfn* для автологина.\n"
                 "Путь к steam.exe — оставь пустым для авто-поиска.",
            foreground="gray",
            justify="left",
        )
        hint.grid(row=row, column=0, columnspan=2, padx=10, pady=2, sticky="w")

        btns = ttk.Frame(win)
        btns.grid(row=row+1, column=0, columnspan=2, pady=15)
        ttk.Button(btns, text="Сохранить", command=self._save).pack(side="left", padx=5)
        ttk.Button(btns, text="Отмена", command=win.destroy).pack(side="left", padx=5)

    def _browse_mafiles(self):
        path = filedialog.askdirectory(
            title="Выбери папку с .maFile",
            parent=self.win,
        )
        if path:
            try:
                rel = Path(path).relative_to(BASE_DIR)
                self.mafiles_var.set(str(rel).replace("\\", "/"))
            except ValueError:
                self.mafiles_var.set(path)

    def _browse_steam(self):
        path = filedialog.askopenfilename(
            title="steam.exe",
            filetypes=[("Программы", "*.exe"), ("Все файлы", "*.*")],
            parent=self.win,
        )
        if path:
            self.steam_var.set(path)

    def _save(self):
        try:
            post_start = float(self.post_start_var.get().strip())
            post_login = float(self.post_login_var.get().strip())
        except ValueError:
            messagebox.showwarning("Внимание", "Задержки должны быть числами (например, 5.0)", parent=self.win)
            return

        self.on_save({
            "chrome_profiles_dir": self.profiles_var.get().strip() or "chrome_profiles",
            "mafiles_dir": self.mafiles_var.get().strip(),
            "steam_exe_path": self.steam_var.get().strip(),
            "post_start_delay": post_start,
            "post_login_delay": post_login,
            "default_appid": self.default_appid_var.get().strip(),
            "save_steam_sessions": self.save_session_var.get(),
            "steam_sessions_dir": self.sessions_dir_var.get().strip() or "steam_sessions",
        })
        self.win.destroy()


class FarmDialog:
    def __init__(self, parent, accounts, indices, config, on_start):
        self.on_start = on_start
        self.accounts = accounts
        self.indices = indices
        settings = config.get("settings", {})

        win = tk.Toplevel(parent)
        win.title(f"Farm ({len(accounts)} аккаунтов)")
        win.geometry("420x480")
        win.transient(parent)
        win.grab_set()
        self.win = win

        ttk.Label(win, text=f"Выбрано аккаунтов: {len(accounts)}").pack(pady=10)

        # --- Блок: Вход ---
        frame_login = ttk.LabelFrame(win, text="Вход в аккаунт", padding=10)
        frame_login.pack(fill="x", padx=10, pady=5)

        ttk.Label(frame_login, text="Ждём Steam после запуска (сек):").grid(row=0, column=0, sticky="w")
        self.post_start_var = tk.StringVar(value=str(settings.get("post_start_delay", 5.0)))
        ttk.Entry(frame_login, textvariable=self.post_start_var, width=10).grid(row=0, column=1, sticky="w", padx=5)

        ttk.Label(frame_login, text="Ждём после входа перед игрой (сек):").grid(row=1, column=0, sticky="w", pady=5)
        self.post_login_var = tk.StringVar(value=str(settings.get("post_login_delay", 5.0)))
        ttk.Entry(frame_login, textvariable=self.post_login_var, width=10).grid(row=1, column=1, sticky="w", padx=5)

        self.run_browser_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(frame_login, text="Использовать браузер (а не клиент Steam)", variable=self.run_browser_var).grid(row=2, column=0, columnspan=2, sticky="w")

        # --- Блок: Игра ---
        frame_game = ttk.LabelFrame(win, text="Запуск игры", padding=10)
        frame_game.pack(fill="x", padx=10, pady=5)

        self.launch_game_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame_game, text="Запускать игру (AppID из аккаунта)", variable=self.launch_game_var).grid(row=0, column=0, columnspan=2, sticky="w")

        ttk.Label(frame_game, text="Время игры на аккаунте (сек):").grid(row=1, column=0, sticky="w", pady=5)
        self.game_time_var = tk.StringVar(value="20")
        ttk.Entry(frame_game, textvariable=self.game_time_var, width=10).grid(row=1, column=1, sticky="w", padx=5)

        # --- Блок: Закрытие ---
        frame_close = ttk.LabelFrame(win, text="Закрытие", padding=10)
        frame_close.pack(fill="x", padx=10, pady=5)

        self.close_steam_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame_close, text="Закрывать Steam после задержки", variable=self.close_steam_var).grid(row=0, column=0, columnspan=2, sticky="w")

        # --- Кнопки ---
        btns = ttk.Frame(win)
        btns.pack(pady=15)
        ttk.Button(btns, text="Запустить", command=self._start).pack(side="left", padx=5)
        ttk.Button(btns, text="Отмена", command=win.destroy).pack(side="left", padx=5)

    def _start(self):
        try:
            post_start = float(self.post_start_var.get().strip())
            post_login = float(self.post_login_var.get().strip())
            game_time = int(self.game_time_var.get().strip())
        except ValueError:
            messagebox.showwarning("Внимание", "Все задержки должны быть числами", parent=self.win)
            return
        self.on_start(
            self.accounts,
            self.indices,
            post_start,
            post_login,
            game_time,
            self.launch_game_var.get(),
            self.close_steam_var.get(),
            self.run_browser_var.get(),
        )
        self.win.destroy()


def _safe_filename(text):
    bad = '<>:"/\\|?*'
    return "".join("_" if c in bad else c for c in text).strip() or "default"


def main():
    if not CONFIG_PATH.exists():
        save_config(load_config())
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
