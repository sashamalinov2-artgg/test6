"""Автоматизация входа в десктопный клиент Steam (GUI-автоматизация формы).

Поток:
  1. Закрываем текущий Steam (со всеми вспомогательными процессами).
  2. Управляем сессией:
     - Если включено сохранение сессий и есть бэкап — восстанавливаем.
     - Иначе — очищаем AutoLoginUser/MostRecent чтобы Steam не автологинился.
  3. Запускаем Steam заново.
  4. Детектируем состояние:
     - Если сессия восстановлена и Steam вошёл сам — пропускаем GUI.
     - Если показан экран "Войти в Steam" — кликаем "+", вводим логин/пароль, Guard.
  5. После успешного входа бэкапим сессию (если включено).

Интерфейс клиента — Chromium (CEF), поэтому используем pywinauto (UI Automation)
для поиска контролов + ввод с клавиатуры. Селекторы подгоняются по реальному
дереву контролов (см. debug_steam_client.py).
"""

import subprocess
import time
import shutil
from pathlib import Path

from logger import logger, log_exc


DEFAULT_STEAM_PATHS = [
    r"C:\Program Files (x86)\Steam\steam.exe",
    r"C:\Program Files\Steam\steam.exe",
]


def _steam_exe_from_registry():
    """Путь к steam.exe из реестра (надёжно при нестандартной установке)."""
    try:
        import winreg
    except ImportError:
        logger.warning("winreg недоступен — не Windows?")
        return None
    for hive, key in (
        (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam"),
    ):
        try:
            with winreg.OpenKey(hive, key) as k:
                for value in ("SteamExe", "InstallPath"):
                    try:
                        raw, _ = winreg.QueryValueEx(k, value)
                    except FileNotFoundError:
                        continue
                    if not raw:
                        continue
                    candidate = Path(raw.replace("/", "\\"))
                    if candidate.is_dir():
                        candidate = candidate / "steam.exe"
                    if candidate.exists():
                        logger.info("steam.exe найден через реестр: %s", candidate)
                        return str(candidate)
        except OSError:
            continue
    return None


def find_steam_exe(configured=None):
    """Находит steam.exe: настройки → реестр → стандартные папки."""
    if configured and Path(configured).exists():
        logger.info("Используется настроенный путь steam.exe: %s", configured)
        return configured

    from_reg = _steam_exe_from_registry()
    if from_reg:
        return from_reg

    for p in DEFAULT_STEAM_PATHS:
        if Path(p).exists():
            logger.info("steam.exe найден по стандартному пути: %s", p)
            return p

    logger.error("steam.exe не найден ни в реестре, ни в стандартных папках")
    return None


# Вспомогательные процессы, которые Steam порождает помимо steam.exe.
# SteamService.exe — системная служба, её НЕ трогаем.
STEAM_PROCESS_NAMES = ("steam.exe", "steamwebhelper.exe")


def _running_pids(image_name):
    """PID'ы процесса по имени образа через tasklist."""
    try:
        out = subprocess.run(
            ["tasklist", "/FI", f"IMAGENAME eq {image_name}", "/FO", "CSV", "/NH"],
            capture_output=True, text=True,
        ).stdout
    except Exception as e:
        logger.warning("tasklist не сработал для %s: %s", image_name, e)
        return set()

    name_lc = image_name.lower()
    pids = set()
    for line in out.splitlines():
        line = line.strip()
        if not line or not line.lower().startswith(f'"{name_lc}'):
            continue
        parts = [p.strip('"') for p in line.split('","')]
        if len(parts) >= 2:
            try:
                pids.add(int(parts[1]))
            except ValueError:
                pass
    return pids


def _pid_name_map():
    """Карта PID -> имя процесса."""
    try:
        out = subprocess.run(
            ["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True
        ).stdout
    except Exception:
        return {}
    mapping = {}
    for line in out.splitlines():
        parts = [p.strip('"') for p in line.split('","')]
        if len(parts) >= 2:
            try:
                mapping[int(parts[1])] = parts[0]
            except ValueError:
                pass
    return mapping


def _steam_pids():
    return _running_pids("steam.exe")


def _all_steam_pids():
    pids = set()
    for name in STEAM_PROCESS_NAMES:
        pids |= _running_pids(name)
    return pids


def is_steam_running():
    return bool(_steam_pids())


def force_kill_all_steam():
    """Принудительно убивает ВСЕ процессы Steam (кроме SteamService)."""
    logger.info("Force kill всех Steam-процессов")
    for name in STEAM_PROCESS_NAMES:
        if _running_pids(name):
            try:
                result = subprocess.run(
                    ["taskkill", "/F", "/IM", name, "/T"],
                    capture_output=True, text=True,
                )
                logger.info("taskkill %s: rc=%s stderr=%s", name, result.returncode, result.stderr.strip())
            except Exception as e:
                logger.warning("taskkill %s не сработал: %s", name, e)
    time.sleep(1.0)
    still = _all_steam_pids()
    if still:
        logger.warning("После force kill остались PID: %s", still)
    return not still


def shutdown_steam(steam_exe, wait_timeout=30, grace=2.0):
    """Корректно закрывает Steam и ВСЕ его вспомогательные процессы."""
    if not _all_steam_pids():
        logger.info("Steam процессы не найдены — нечего закрывать")
        return True

    try:
        subprocess.Popen([steam_exe, "-shutdown"])
        logger.info("Отправлена команда -shutdown к steam.exe")
    except Exception as e:
        logger.warning("Не удалось отправить -shutdown: %s", e)

    deadline = time.time() + wait_timeout
    while time.time() < deadline:
        alive = _all_steam_pids()
        if not alive:
            logger.info("Все Steam процессы завершены, жду grace %ss", grace)
            time.sleep(grace)
            return True
        time.sleep(0.5)

    logger.warning("Steam не закрылся за %ss — force kill", wait_timeout)
    return force_kill_all_steam()


# ---------------------------------------------------------------------------
# VDF (Valve Data Format) парсер/райтер
# ---------------------------------------------------------------------------

def _parse_vdf(text: str) -> dict:
    """Простой парсер VDF в dict. Поддерживает строки и вложенные dict."""
    root = {}
    stack = [root]
    i = 0
    n = len(text)
    while i < n:
        if text[i].isspace() or text[i] == '}':
            if text[i] == '}' and len(stack) > 1:
                stack.pop()
            i += 1
            continue
        if text[i] == '"':
            i += 1
            start = i
            while i < n and text[i] != '"':
                i += 1
            key = text[start:i]
            i += 1  # skip closing quote
            while i < n and text[i].isspace():
                i += 1
            if i < n and text[i] == '"':
                i += 1
                start = i
                while i < n and text[i] != '"':
                    i += 1
                value = text[start:i]
                i += 1
                stack[-1][key] = value
            elif i < n and text[i] == '{':
                i += 1
                new_dict = {}
                stack[-1][key] = new_dict
                stack.append(new_dict)
            else:
                # skip unexpected token
                pass
        else:
            i += 1
    return root


def _write_vdf(data: dict, indent: int = 0) -> str:
    """Простой writer VDF."""
    lines = []
    tab = "\t" * indent
    for key, val in data.items():
        if isinstance(val, dict):
            lines.append(f'{tab}"{key}"')
            lines.append(f"{tab}{{")
            lines.append(_write_vdf(val, indent + 1))
            lines.append(f"{tab}}}")
        else:
            lines.append(f'{tab}"{key}"\t\t"{val}"')
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Управление сессиями Steam
# ---------------------------------------------------------------------------

def _get_steam_path(steam_exe: str) -> str:
    """Возвращает папку установки Steam."""
    if steam_exe:
        p = Path(steam_exe).parent
        if p.exists():
            return str(p)
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
            path, _ = winreg.QueryValueEx(k, "SteamPath")
            return path.replace("/", "\\")
    except Exception:
        pass
    return None


def _safe_filename(text: str) -> str:
    bad = '<>:"/\\|?*'
    return "".join("_" if c in bad else c for c in text).strip() or "default"


def clear_steam_session(steam_path: str):
    """Очищает AutoLoginUser и MostRecent чтобы Steam не автологинился."""
    if not steam_path:
        return
    sp = Path(steam_path)

    # config.vdf
    config_path = sp / "config" / "config.vdf"
    if config_path.exists():
        try:
            text = config_path.read_text(encoding="utf-8")
            data = _parse_vdf(text)
            ic = data.get("InstallConfigStore", {})
            sw = ic.get("Software", {})
            val = sw.get("Valve", {})
            steam = val.get("Steam", {})
            if "AutoLoginUser" in steam:
                steam["AutoLoginUser"] = ""
                config_path.write_text(_write_vdf(data), encoding="utf-8")
                logger.info("Очищен AutoLoginUser в config.vdf")
        except Exception as e:
            logger.warning("Не удалось очистить config.vdf: %s", e)

    # loginusers.vdf
    loginusers_path = sp / "config" / "loginusers.vdf"
    if loginusers_path.exists():
        try:
            text = loginusers_path.read_text(encoding="utf-8")
            data = _parse_vdf(text)
            users = data.get("users", {})
            cleared = False
            for uid, udata in users.items():
                if isinstance(udata, dict):
                    udata["MostRecent"] = "0"
                    cleared = True
            if cleared:
                loginusers_path.write_text(_write_vdf(data), encoding="utf-8")
                logger.info("Сброшен MostRecent для всех пользователей в loginusers.vdf")
        except Exception as e:
            logger.warning("Не удалось очистить loginusers.vdf: %s", e)

    # registry
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", 0, winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, "AutoLoginUser", 0, winreg.REG_SZ, "")
            logger.info("Очищен AutoLoginUser в реестре")
    except Exception as e:
        logger.warning("Не удалось очистить AutoLoginUser в реестре: %s", e)


def backup_steam_session(steam_path: str, login: str, backup_dir: str):
    """Бэкапит сессию Steam (config.vdf, loginusers.vdf, ssfn*)."""
    if not steam_path or not login or not backup_dir:
        return
    sp = Path(steam_path)
    bd = Path(backup_dir) / _safe_filename(login)
    bd.mkdir(parents=True, exist_ok=True)

    files = [
        sp / "config" / "config.vdf",
        sp / "config" / "loginusers.vdf",
    ]
    for f in sp.glob("ssfn*"):
        files.append(f)

    copied = 0
    for src in files:
        if src.exists():
            try:
                if src.name in ("config.vdf", "loginusers.vdf"):
                    dst_dir = bd / "config"
                    dst_dir.mkdir(exist_ok=True)
                    dst = dst_dir / src.name
                else:
                    dst = bd / src.name
                shutil.copy2(str(src), str(dst))
                copied += 1
            except Exception as e:
                logger.warning("Бэкап %s не удался: %s", src, e)
    logger.info("Сессия бэкапирована для '%s': %s файлов в %s", login, copied, bd)


def restore_steam_session(steam_path: str, login: str, backup_dir: str) -> bool:
    """Восстанавливает сессию Steam из бэкапа."""
    if not steam_path or not login or not backup_dir:
        return False
    bd = Path(backup_dir) / _safe_filename(login)
    if not bd.exists():
        return False
    sp = Path(steam_path)

    # Удаляем старые ssfn чтобы не было конфликтов
    for f in sp.glob("ssfn*"):
        try:
            f.unlink()
            logger.info("Удалён старый ssfn: %s", f)
        except Exception as e:
            logger.warning("Не удалось удалить %s: %s", f, e)

    restored = 0
    for src in bd.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(bd)
        dst = sp / rel
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dst))
            restored += 1
        except Exception as e:
            logger.warning("Восстановление %s не удалось: %s", src, e)
    logger.info("Сессия восстановлена для '%s': %s файлов", login, restored)
    return restored > 0


# ---------------------------------------------------------------------------
# Координаты — доли (fx, fy) относительно окна 'Войти в Steam' (class SDL_app).
# Steam-CEF не отдаёт контролы через UIA, поэтому кликаем по координатам.
# ---------------------------------------------------------------------------
STEAM_UI_WINDOW_CLASS = "SDL_app"
LOGIN_FORM_TITLE = "Войти в Steam"

# Экран "Кто играет?" — кнопка "+" (добавить аккаунт). Справа от аватарок.
PICKER_ADD_FRAC = (0.90, 0.55)

# Форма логина — поля и кнопка.
FORM_USERNAME_FRAC = (0.33, 0.32)
FORM_PASSWORD_FRAC = (0.33, 0.50)
FORM_LOGIN_BTN_FRAC = (0.33, 0.69)

# Экран "Подтвердите вход через моб. приложение" — ссылка "Войти с помощью кода".
LOGIN_WITH_CODE_FRAC = (0.50, 0.74)

# Тайминги (секунды).
CODE_SCREEN_WAIT = 1.5
POST_ENTER_WAIT = 3.5


def _escape_keys(text):
    """Экранирует спецсимволы pywinauto.keyboard ( +^%~(){}[] )."""
    special = set("+^%~(){}[]")
    return "".join("{%s}" % ch if ch in special else ch for ch in text)


def _type_text(text):
    import pywinauto.keyboard as keyboard
    keyboard.send_keys(_escape_keys(text), pause=0.02, with_spaces=True)


def _send(keys):
    import pywinauto.keyboard as keyboard
    keyboard.send_keys(keys, pause=0.05)


def _find_steam_ui_window(timeout=90, title_contains=None):
    """Находит видимое окно Steam-UI (class SDL_app у steamwebhelper.exe)."""
    from pywinauto import Desktop

    deadline = time.time() + timeout
    while time.time() < deadline:
        pids = _all_steam_pids()
        if pids:
            try:
                for w in Desktop(backend="uia").windows():
                    try:
                        if not w.is_visible() or w.process_id() not in pids:
                            continue
                        if w.class_name() != STEAM_UI_WINDOW_CLASS:
                            continue
                        title = (w.window_text() or "")
                        if title_contains and title_contains.lower() not in title.lower():
                            continue
                        logger.info("Найдено окно Steam: title='%s' class=%s pid=%s", title, w.class_name(), w.process_id())
                        return w
                    except Exception:
                        continue
            except Exception as e:
                logger.debug("Ошибка перечисления окон: %s", e)
        time.sleep(0.5)
    logger.warning("Окно Steam-UI не найдено за %ss (title_contains=%s)", timeout, title_contains)
    return None


def _abs_coords(window, fx, fy):
    r = window.rectangle()
    return int(r.left + fx * r.width()), int(r.top + fy * r.height())


def _click_fraction(window, fx, fy, retries=3):
    """Кликает по точке (доля окна) и возвращает фокус окну."""
    from pywinauto import mouse

    for attempt in range(retries):
        try:
            window.set_focus()
        except Exception as e:
            logger.debug("set_focus не сработал (%s), попытка %s/%s", e, attempt+1, retries)
        time.sleep(0.2)
        try:
            x, y = _abs_coords(window, fx, fy)
            logger.info("Клик по координатам (%s, %s) [доли %.2f, %.2f]", x, y, fx, fy)
            mouse.click(button="left", coords=(x, y))
            time.sleep(0.2)
            return
        except Exception as e:
            logger.warning("Клик не сработал (%s), попытка %s/%s", e, attempt+1, retries)
            time.sleep(0.3)
    raise RuntimeError(f"Не удалось кликнуть по координатам ({fx}, {fy}) после {retries} попыток")


def login_steam_client(
    steam_exe,
    username,
    password,
    guard_code_callback,
    status_callback=None,
    restart_if_running=True,
    post_start_delay=5.0,
    save_session=False,
    session_backup_dir=None,
):
    """Логинит аккаунт в десктопный клиент Steam через GUI-автоматизацию.

    Поток: закрыть Steam → управление сессией → запустить → детект →
    GUI-логин (если нужен) → Steam Guard. Сессия бэкапится при выходе.
    """
    def status(text):
        if status_callback:
            status_callback(text)
        logger.info("[STATUS] %s", text)

    if not steam_exe or not Path(steam_exe).exists():
        raise FileNotFoundError("steam.exe не найден. Укажи путь к Steam в Настройках.")

    steam_path = _get_steam_path(steam_exe)

    if restart_if_running and is_steam_running():
        status("Закрываю текущий Steam...")
        if not shutdown_steam(steam_exe):
            raise RuntimeError(
                "Не удалось закрыть запущенный Steam. Закрой его вручную и повтори."
            )

    # --- Управление сессией ---
    session_restored = False
    if save_session and session_backup_dir and restore_steam_session(steam_path, username, session_backup_dir):
        status("Восстановлена сессия Steam...")
        session_restored = True
    else:
        clear_steam_session(steam_path)
        status("Сессия очищена (предотвращён автологин)...")

    status("Запускаю Steam...")
    try:
        subprocess.Popen([steam_exe])
        logger.info("steam.exe запущен: %s", steam_exe)
    except Exception as e:
        raise RuntimeError(f"Не удалось запустить Steam: {e}")

    # --- Детект окна ---
    status("Жду окно Steam...")
    window = _find_steam_ui_window(timeout=120)
    if window is None:
        if session_restored and is_steam_running():
            status("Вход выполнен автоматически (Steam в трее)")
            if save_session and session_backup_dir:
                time.sleep(3.0)
                backup_steam_session(steam_path, username, session_backup_dir)
            return
        raise RuntimeError(
            "Окно входа Steam не появилось. Возможно Steam сразу зашёл в аккаунт — "
            "сделай Steam → Сменить аккаунт и повтори."
        )
    time.sleep(post_start_delay)

    # Если сессия восстановлена и окно НЕ "Войти в Steam" — вход выполнен сам
    title = (window.window_text() or "").lower()
    if session_restored and "войти" not in title:
        status("Вход выполнен автоматически (сессия активна)")
        if save_session and session_backup_dir:
            time.sleep(3.0)
            backup_steam_session(steam_path, username, session_backup_dir)
        return

    # --- GUI-логин ---
    status("Открываю форму логина (+)...")
    _click_fraction(window, *PICKER_ADD_FRAC)
    time.sleep(1.5)

    window = _find_steam_ui_window(timeout=15) or window

    status("Ввожу логин и пароль...")
    _fill_login_form(window, username, password)

    status(f"Жду {POST_ENTER_WAIT}с, пока Steam отрисует экран Guard...")
    logger.info("Жду %.1f секунд после отправки формы", POST_ENTER_WAIT)
    time.sleep(POST_ENTER_WAIT)

    # Всегда кликаем "Use code instead / Войти с помощью кода"
    # Steam иногда показывает экран "Подтвердите через моб. приложение".
    # Этот клик гарантированно переключает на поле ввода кода.
    status("Переключаю на ввод кода (Use code instead)...")
    window = _find_steam_ui_window(timeout=15) or window
    try:
        _click_fraction(window, *LOGIN_WITH_CODE_FRAC, retries=2)
        logger.info("Кликнул 'Use code instead / Войти с помощью кода'")
    except Exception as e:
        logger.warning("Клик по 'Use code instead' не сработал: %s", e)

    # Ждём, пока Steam переключится на поле ввода кода
    status("Жду появления поля ввода кода...")
    time.sleep(CODE_SCREEN_WAIT + 1.0)

    # Получаем и вводим код
    status("Получаю Steam Guard код...")
    code = guard_code_callback()
    logger.info("Код получен: %s", code)

    window = _find_steam_ui_window(timeout=15) or window
    status(f"Ввожу код {code}...")
    _type_guard_code(window, code)
    status("Код введён — проверь окно Steam")
    logger.info("Ввод кода завершён для пользователя %s", username)

    # Проверяем, ушли ли мы с экрана логина
    time.sleep(5)
    w_check = _find_steam_ui_window(timeout=5)
    if w_check is None:
        status("Вход выполнен!")
        logger.info("Окно Steam исчезло — вход выполнен")
    else:
        title = (w_check.window_text() or "").lower()
        if "войти" not in title:
            status("Вход выполнен!")
            logger.info("Заголовок окна изменился на '%s' — вход выполнен", w_check.window_text())
        else:
            logger.warning("Окно 'Войти в Steam' всё ещё открыто после ввода кода")

    if save_session and session_backup_dir:
        time.sleep(3.0)
        backup_steam_session(steam_path, username, session_backup_dir)


def _fill_login_form(window, username, password):
    """Кликает по полям формы логина и печатает данные с клавиатуры."""
    _click_fraction(window, *FORM_USERNAME_FRAC)
    _send("^a")
    time.sleep(0.1)
    _type_text(username)
    logger.info("Логин введён")
    time.sleep(0.2)

    _click_fraction(window, *FORM_PASSWORD_FRAC)
    _send("^a")
    time.sleep(0.1)
    _type_text(password)
    logger.info("Пароль введён")
    time.sleep(0.2)

    _send("{ENTER}")
    time.sleep(0.6)
    logger.info("Форма отправлена (Enter)")


def _type_guard_code(window, code):
    """Печатает Steam Guard код. Перед вводом кликает по центру окна,
    чтобы гарантированно убрать фокус с поля пароля."""
    code = code.strip().upper()
    if len(code) != 5:
        raise ValueError(f"Неверная длина кода: {code!r}")

    try:
        window.set_focus()
        time.sleep(0.2)
        _click_fraction(window, 0.50, 0.50, retries=1)
        logger.info("Клик по центру окна для переключения фокуса")
    except Exception as e:
        logger.warning("Клик по центру не сработал: %s", e)

    time.sleep(0.4)
    logger.info("Ввожу Steam Guard код...")
    for ch in code:
        _send(ch)
        time.sleep(0.08)
    logger.info("Код введён посимвольно")
