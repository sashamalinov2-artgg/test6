"""Графический интерфейс для настройки автоматизации и автокликера (Game Automation).

Позволяет:
- Настраивать последовательность игровых кликов (game_sequence).
- Захватывать координаты кнопок по горячей клавише F1 или вводить X, Y вручную.
- Добавлять и удалять пользовательские кнопки.
- Менять порядок кликов стрелками ↑ / ↓.
- Настраивать кнопки веб-событий (координаты или поиск по шаблону изображения).
- Делать захват скриншота кнопки по F1 (сохраняется в button_templates/).
- Настраивать КД и задержки (перед кликами, между кликами, после сбора наград, между аккаунтами, скролл).
- Тестировать клики прямо из окна программы.
"""

import os
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path

from logger import logger, log_exc
from automation import GameAutomation, HAS_IMAGE_MATCH, HAS_PYAUTOGUI, HAS_PYNPUT


class AutomationDialog:
    """Окно настройки автокликера и последовательности кликов."""

    def __init__(self, parent, automation: GameAutomation, on_save_callback=None):
        self.parent = parent
        self.automation = automation
        self.on_save_callback = on_save_callback

        win = tk.Toplevel(parent)
        win.title("🎮 Настройки автокликера / Автоматизации")
        win.geometry("720x620")
        win.minsize(680, 560)
        win.transient(parent)
        win.grab_set()
        self.win = win

        # Создаем вкладки Notebook
        notebook = ttk.Notebook(win)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.tab_game = ttk.Frame(notebook, padding=10)
        self.tab_web = ttk.Frame(notebook, padding=10)
        self.tab_delays = ttk.Frame(notebook, padding=10)

        notebook.add(self.tab_game, text="🎮 Игровые кнопки")
        notebook.add(self.tab_web, text="🌐 Кнопки веб-событий")
        notebook.add(self.tab_delays, text="⏱️ Задержки и КД")

        self._build_game_tab()
        self._build_web_tab()
        self._build_delays_tab()

        # Нижняя панель с кнопками Сохранить / Закрыть и строкой статуса
        bottom_frame = ttk.Frame(win, padding=(10, 5))
        bottom_frame.pack(fill="x", side="bottom")

        self.status_lbl = ttk.Label(bottom_frame, text="Готов к настройке", relief="sunken", anchor="w", padding=3)
        self.status_lbl.pack(fill="x", side="top", pady=(0, 5))

        btn_box = ttk.Frame(bottom_frame)
        btn_box.pack(fill="x", side="bottom")

        ttk.Button(btn_box, text="💾 Сохранить всё", command=self._save_and_close).pack(side="left", padx=5)
        ttk.Button(btn_box, text="⚡ Протестировать клики (F5)", command=self._test_clicks_threaded).pack(side="left", padx=5)
        ttk.Button(btn_box, text="Закрыть", command=self._on_close).pack(side="right", padx=5)

        self.win.protocol("WM_DELETE_WINDOW", self._on_close)

    def set_status(self, text):
        def _upd():
            self.status_lbl.config(text=text)
        self.win.after(0, _upd)

    # ---------------- TAB 1: Игровые кнопки ----------------
    def _build_game_tab(self):
        tab = self.tab_game

        # Верхнее описание
        header = ttk.Label(
            tab,
            text="Настройка последовательности игровых кликов (например, сбор наград / пропуск окон).\n"
                 "Клики выполняются сверху вниз по порядку списка с задержкой 'Между кликами'.",
            justify="left"
        )
        header.pack(fill="x", pady=(0, 8))

        # Фрейм с чекбоксом включения
        top_opts = ttk.Frame(tab)
        top_opts.pack(fill="x", pady=(0, 5))

        self.enabled_var = tk.BooleanVar(value=self.automation.settings.get("enabled", True))
        ttk.Checkbutton(
            top_opts,
            text="Включить выполнение автокликера при фарме",
            variable=self.enabled_var
        ).pack(side="left")

        # Список кнопок и таблица координат
        list_frame = ttk.Frame(tab)
        list_frame.pack(fill="both", expand=True, pady=5)

        cols = ("name", "coords")
        self.tree_game = ttk.Treeview(list_frame, columns=cols, show="headings", height=8, selectmode="browse")
        self.tree_game.heading("name", text="Название кнопки / Шага")
        self.tree_game.heading("coords", text="Координаты (X, Y)")
        self.tree_game.column("name", width=260)
        self.tree_game.column("coords", width=160, anchor="center")
        self.tree_game.pack(side="left", fill="both", expand=True)

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree_game.yview)
        self.tree_game.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")

        self.tree_game.bind("<Double-1>", lambda e: self._edit_selected_game_coords())

        # Кнопки управления порядком и кнопками
        ctrl_frame = ttk.Frame(tab)
        ctrl_frame.pack(fill="x", pady=6)

        ttk.Button(ctrl_frame, text="🎯 Захватить по F1", command=self._capture_selected_f1).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="✏️ Задать вручную", command=self._edit_selected_game_coords).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="➕ Добавить шаг", command=self._add_game_button).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="🗑️ Удалить", command=self._remove_game_button).pack(side="left", padx=3)

        ttk.Separator(ctrl_frame, orient="vertical").pack(side="left", fill="y", padx=6)

        ttk.Button(ctrl_frame, text="↑ Вверх", width=8, command=self._move_game_up).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="↓ Вниз", width=8, command=self._move_game_down).pack(side="left", padx=3)

        self._refresh_game_list()

    def _refresh_game_list(self):
        for item in self.tree_game.get_children():
            self.tree_game.delete(item)

        seq = self.automation.settings.get("game_sequence", [])
        buttons = self.automation.settings.get("buttons", {})

        for name in seq:
            coords = buttons.get(name, [0, 0])
            coord_str = f"({coords[0]}, {coords[1]})"
            self.tree_game.insert("", "end", iid=name, values=(name, coord_str))

    def _get_selected_game_button(self):
        sel = self.tree_game.selection()
        if not sel:
            messagebox.showwarning("Внимание", "Выберите кнопку в списке", parent=self.win)
            return None
        return sel[0]

    def _capture_selected_f1(self):
        btn_name = self._get_selected_game_button()
        if not btn_name:
            return

        if not HAS_PYNPUT:
            messagebox.showerror(
                "Ошибка",
                "Библиотека pynput не установлена.\n"
                "Вы можете задать координаты вручную кнопкой 'Задать вручную'.",
                parent=self.win
            )
            return

        self.set_status(f"Наведите курсор на '{btn_name}' и нажмите F1...")

        def _on_captured(name, x, y):
            self._refresh_game_list()
            self.set_status(f"Координаты для '{name}' сохранены: ({x}, {y})")

        self.automation.start_capture(
            btn_name,
            on_captured_callback=_on_captured,
            status_callback=self.set_status
        )

    def _edit_selected_game_coords(self):
        btn_name = self._get_selected_game_button()
        if not btn_name:
            return

        coords = self.automation.settings.get("buttons", {}).get(btn_name, [0, 0])
        self._show_coords_edit_dialog(btn_name, coords)

    def _show_coords_edit_dialog(self, btn_name, initial_coords):
        dialog = tk.Toplevel(self.win)
        dialog.title(f"Координаты: {btn_name}")
        dialog.geometry("340x220")
        dialog.transient(self.win)
        dialog.grab_set()

        ttk.Label(dialog, text=f"Кнопка: {btn_name}", font=("", 10, "bold")).pack(pady=8)

        form = ttk.Frame(dialog, padding=10)
        form.pack(fill="both", expand=True)

        ttk.Label(form, text="X (пиксели):").grid(row=0, column=0, sticky="w", pady=4)
        x_entry = ttk.Entry(form, width=15)
        x_entry.insert(0, str(initial_coords[0]))
        x_entry.grid(row=0, column=1, padx=8, pady=4)

        ttk.Label(form, text="Y (пиксели):").grid(row=1, column=0, sticky="w", pady=4)
        y_entry = ttk.Entry(form, width=15)
        y_entry.insert(0, str(initial_coords[1]))
        y_entry.grid(row=1, column=1, padx=8, pady=4)

        def _save_manual():
            try:
                x = int(x_entry.get().strip())
                y = int(y_entry.get().strip())
                self.automation.set_coords_manual(btn_name, x, y)
                self._refresh_game_list()
                dialog.destroy()
                self.set_status(f"Координаты '{btn_name}' обновлены: ({x}, {y})")
            except ValueError:
                messagebox.showerror("Ошибка", "Координаты должны быть целыми числами!", parent=dialog)

        btns = ttk.Frame(dialog)
        btns.pack(pady=10)
        ttk.Button(btns, text="Сохранить", command=_save_manual).pack(side="left", padx=5)
        ttk.Button(btns, text="Отмена", command=dialog.destroy).pack(side="left", padx=5)

    def _add_game_button(self):
        dialog = tk.Toplevel(self.win)
        dialog.title("Новая кнопка игры")
        dialog.geometry("360x170")
        dialog.transient(self.win)
        dialog.grab_set()

        ttk.Label(dialog, text="Название действия/кнопки:").pack(pady=(12, 4))
        name_entry = ttk.Entry(dialog, width=30)
        name_entry.pack(pady=4)
        name_entry.focus()

        def _create():
            name = name_entry.get().strip()
            if not name:
                messagebox.showwarning("Внимание", "Имя не может быть пустым", parent=dialog)
                return

            seq = self.automation.settings.setdefault("game_sequence", [])
            btns = self.automation.settings.setdefault("buttons", {})

            if name in btns:
                messagebox.showwarning("Внимание", f"Кнопка '{name}' уже существует!", parent=dialog)
                return

            btns[name] = [0, 0]
            seq.append(name)
            self.automation.save_settings()
            self._refresh_game_list()
            dialog.destroy()
            self.set_status(f"Кнопка '{name}' создана. Задайте координаты по F1.")

        btns = ttk.Frame(dialog)
        btns.pack(pady=12)
        ttk.Button(btns, text="Создать", command=_create).pack(side="left", padx=5)
        ttk.Button(btns, text="Отмена", command=dialog.destroy).pack(side="left", padx=5)

    def _remove_game_button(self):
        btn_name = self._get_selected_game_button()
        if not btn_name:
            return

        if messagebox.askyesno("Удаление", f"Удалить кнопку '{btn_name}' из последовательности?", parent=self.win):
            seq = self.automation.settings.get("game_sequence", [])
            if btn_name in seq:
                seq.remove(btn_name)
            btns = self.automation.settings.get("buttons", {})
            if btn_name in btns:
                del btns[btn_name]
            self.automation.save_settings()
            self._refresh_game_list()
            self.set_status(f"Кнопка '{btn_name}' удалена")

    def _move_game_up(self):
        btn_name = self._get_selected_game_button()
        if not btn_name:
            return
        seq = self.automation.settings.get("game_sequence", [])
        if btn_name not in seq:
            return
        idx = seq.index(btn_name)
        if idx > 0:
            seq[idx], seq[idx - 1] = seq[idx - 1], seq[idx]
            self.automation.save_settings()
            self._refresh_game_list()
            self.tree_game.selection_set(btn_name)

    def _move_game_down(self):
        btn_name = self._get_selected_game_button()
        if not btn_name:
            return
        seq = self.automation.settings.get("game_sequence", [])
        if btn_name not in seq:
            return
        idx = seq.index(btn_name)
        if idx < len(seq) - 1:
            seq[idx], seq[idx + 1] = seq[idx + 1], seq[idx]
            self.automation.save_settings()
            self._refresh_game_list()
            self.tree_game.selection_set(btn_name)

    # ---------------- TAB 2: Веб-кнопки ----------------
    def _build_web_tab(self):
        tab = self.tab_web

        header = ttk.Label(
            tab,
            text="Кнопки для веб-событий (внутриигровой браузер / баннеры).\n"
                 "Поддерживается клик по фиксированным координатам или по шаблону изображения (картинке).",
            justify="left"
        )
        header.pack(fill="x", pady=(0, 8))

        list_frame = ttk.Frame(tab)
        list_frame.pack(fill="both", expand=True, pady=5)

        cols = ("name", "method", "details")
        self.tree_web = ttk.Treeview(list_frame, columns=cols, show="headings", height=8, selectmode="browse")
        self.tree_web.heading("name", text="Название кнопки")
        self.tree_web.heading("method", text="Метод клика")
        self.tree_web.heading("details", text="Параметры / Координаты")
        self.tree_web.column("name", width=180)
        self.tree_web.column("method", width=140, anchor="center")
        self.tree_web.column("details", width=220, anchor="center")
        self.tree_web.pack(side="left", fill="both", expand=True)

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree_web.yview)
        self.tree_web.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")

        ctrl_frame = ttk.Frame(tab)
        ctrl_frame.pack(fill="x", pady=6)

        ttk.Button(ctrl_frame, text="➕ Добавить веб-кнопку", command=self._add_web_button).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="✏️ Настроить", command=self._edit_web_button).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="🗑️ Удалить", command=self._remove_web_button).pack(side="left", padx=3)
        ttk.Button(ctrl_frame, text="📂 Папка шаблонов картинок", command=self._open_templates_dir).pack(side="right", padx=3)

        self._refresh_web_list()

    def _refresh_web_list(self):
        for item in self.tree_web.get_children():
            self.tree_web.delete(item)

        web_btns = self.automation.settings.get("website_buttons", [])
        web_cfg = self.automation.settings.get("website_button_settings", {})

        for name in web_btns:
            cfg = web_cfg.get(name, {})
            m = cfg.get("method", "coords")
            if m == "coords":
                c = cfg.get("coords", [0, 0])
                method_str = "Координаты (X, Y)"
                details_str = f"({c[0]}, {c[1]})"
            else:
                method_str = "По картинке"
                tmpl_exists = (self.automation.templates_dir / f"{name}.png").exists()
                details_str = f"Файл {name}.png: {'✓ Есть' if tmpl_exists else '❌ Нет'}"

            self.tree_web.insert("", "end", iid=name, values=(name, method_str, details_str))

    def _get_selected_web_button(self):
        sel = self.tree_web.selection()
        if not sel:
            messagebox.showwarning("Внимание", "Выберите веб-кнопку в списке", parent=self.win)
            return None
        return sel[0]

    def _add_web_button(self):
        dialog = tk.Toplevel(self.win)
        dialog.title("Новая веб-кнопка")
        dialog.geometry("380x230")
        dialog.transient(self.win)
        dialog.grab_set()

        ttk.Label(dialog, text="Название кнопки:").pack(pady=(10, 2))
        name_entry = ttk.Entry(dialog, width=32)
        name_entry.pack(pady=4)
        name_entry.focus()

        ttk.Label(dialog, text="Способ поиска кнопки:").pack(pady=(8, 2))
        method_var = tk.StringVar(value="coords")
        ttk.Radiobutton(dialog, text="По координатам (X, Y)", variable=method_var, value="coords").pack(anchor="w", padx=30)
        ttk.Radiobutton(dialog, text="По шаблону изображения (скриншот)", variable=method_var, value="image").pack(anchor="w", padx=30)

        def _create():
            name = name_entry.get().strip()
            if not name:
                messagebox.showwarning("Внимание", "Имя не может быть пустым", parent=dialog)
                return

            web_btns = self.automation.settings.setdefault("website_buttons", [])
            web_cfg = self.automation.settings.setdefault("website_button_settings", {})

            if name in web_btns:
                messagebox.showwarning("Внимание", f"Веб-кнопка '{name}' уже есть!", parent=dialog)
                return

            web_btns.append(name)
            web_cfg[name] = {
                "method": method_var.get(),
                "coords": [0, 0]
            }
            self.automation.save_settings()
            self._refresh_web_list()
            dialog.destroy()
            self._edit_web_button_by_name(name)

        btns = ttk.Frame(dialog)
        btns.pack(pady=12)
        ttk.Button(btns, text="Создать", command=_create).pack(side="left", padx=5)
        ttk.Button(btns, text="Отмена", command=dialog.destroy).pack(side="left", padx=5)

    def _edit_web_button(self):
        name = self._get_selected_web_button()
        if not name:
            return
        self._edit_web_button_by_name(name)

    def _edit_web_button_by_name(self, name):
        cfg = self.automation.settings.get("website_button_settings", {}).get(name, {})
        method = cfg.get("method", "coords")

        dialog = tk.Toplevel(self.win)
        dialog.title(f"Настройка: {name}")
        dialog.geometry("420x260")
        dialog.transient(self.win)
        dialog.grab_set()

        ttk.Label(dialog, text=f"Веб-кнопка: {name}", font=("", 10, "bold")).pack(pady=8)
        ttk.Label(dialog, text=f"Режим: {'Координаты' if method == 'coords' else 'По картинке'}").pack(pady=2)

        if method == "coords":
            coords = cfg.get("coords", [0, 0])
            form = ttk.Frame(dialog, padding=10)
            form.pack(fill="x")

            ttk.Label(form, text="X:").grid(row=0, column=0, sticky="w", pady=4)
            x_entry = ttk.Entry(form, width=15)
            x_entry.insert(0, str(coords[0]))
            x_entry.grid(row=0, column=1, padx=8, pady=4)

            ttk.Label(form, text="Y:").grid(row=1, column=0, sticky="w", pady=4)
            y_entry = ttk.Entry(form, width=15)
            y_entry.insert(0, str(coords[1]))
            y_entry.grid(row=1, column=1, padx=8, pady=4)

            def _save_c():
                try:
                    x = int(x_entry.get().strip())
                    y = int(y_entry.get().strip())
                    cfg["coords"] = [x, y]
                    self.automation.save_settings()
                    self._refresh_web_list()
                    dialog.destroy()
                    self.set_status(f"Координаты для {name} сохранены: ({x}, {y})")
                except ValueError:
                    messagebox.showerror("Ошибка", "Должны быть числа", parent=dialog)

            def _cap_f1():
                dialog.withdraw()
                self.set_status(f"Наведите курсор на кнопку '{name}' и нажмите F1...")

                def _captured(n, x, y):
                    cfg["coords"] = [x, y]
                    self.automation.save_settings()
                    self._refresh_web_list()
                    self.set_status(f"Захвачены координаты {name}: ({x}, {y})")

                self.automation.start_capture(name, on_captured_callback=_captured, status_callback=self.set_status)

            btns = ttk.Frame(dialog)
            btns.pack(pady=10)
            ttk.Button(btns, text="💾 Сохранить", command=_save_c).pack(side="left", padx=4)
            ttk.Button(btns, text="🎯 Захватить по F1", command=_cap_f1).pack(side="left", padx=4)
            ttk.Button(btns, text="Отмена", command=dialog.destroy).pack(side="left", padx=4)

        else:
            tmpl_file = self.automation.templates_dir / f"{name}.png"
            ttk.Label(
                dialog,
                text="Сделайте скриншот фрагмента кнопки и сохраните в:\n"
                     f"{tmpl_file}\n\nЛибо нажмите 'Захват скриншота по F1'.",
                justify="center"
            ).pack(pady=10)

            def _cap_img():
                if not HAS_IMAGE_MATCH or not HAS_PYNPUT:
                    messagebox.showerror("Ошибка", "Необходимы Pillow и pynput для захвата картинки", parent=dialog)
                    return
                dialog.withdraw()
                self.set_status(f"Наведите мышь на центр кнопки '{name}' и нажмите F1 для скриншота...")

                from pynput import keyboard
                from PIL import ImageGrab
                import pyautogui

                def on_p(key):
                    if key == keyboard.Key.f1:
                        try:
                            x, y = pyautogui.position()
                            left = max(0, x - 50)
                            top = max(0, y - 25)
                            right = x + 50
                            bottom = y + 25
                            img = ImageGrab.grab(bbox=(left, top, right, bottom))
                            img.save(str(tmpl_file))
                            self.set_status(f"Шаблон сохранен: {tmpl_file.name}")
                            self._refresh_web_list()
                        except Exception as ex:
                            log_exc("Ошибка скриншота", ex)
                        return False

                lis = keyboard.Listener(on_press=on_p)
                lis.daemon = True
                lis.start()

            btns = ttk.Frame(dialog)
            btns.pack(pady=10)
            ttk.Button(btns, text="📸 Захват скриншота (F1)", command=_cap_img).pack(side="left", padx=4)
            ttk.Button(btns, text="📂 Открыть папку", command=self._open_templates_dir).pack(side="left", padx=4)
            ttk.Button(btns, text="Закрыть", command=dialog.destroy).pack(side="left", padx=4)

    def _remove_web_button(self):
        name = self._get_selected_web_button()
        if not name:
            return
        if messagebox.askyesno("Удаление", f"Удалить веб-кнопку '{name}'?", parent=self.win):
            w_btns = self.automation.settings.get("website_buttons", [])
            if name in w_btns:
                w_btns.remove(name)
            w_cfg = self.automation.settings.get("website_button_settings", {})
            if name in w_cfg:
                del w_cfg[name]
            self.automation.save_settings()
            self._refresh_web_list()
            self.set_status(f"Веб-кнопка '{name}' удалена")

    def _open_templates_dir(self):
        p = self.automation.templates_dir.resolve()
        if os.name == "nt" and hasattr(os, "startfile"):
            os.startfile(str(p))
        else:
            import subprocess
            subprocess.Popen(["xdg-open", str(p)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # ---------------- TAB 3: Задержки и КД ----------------
    def _build_delays_tab(self):
        tab = self.tab_delays
        delays = self.automation.settings.get("delays", {})

        header = ttk.Label(
            tab,
            text="Тайминги, кулдауны кликов и ожидания процессов.\n"
                 "Все задержки указываются в секундах.",
            justify="left"
        )
        header.pack(fill="x", pady=(0, 10))

        form = ttk.LabelFrame(tab, text="⏱️ КД и задержки кликов", padding=12)
        form.pack(fill="x", pady=5)

        row = 0

        # process_name
        ttk.Label(form, text="Имя процесса игры (exe):").grid(row=row, column=0, sticky="w", pady=4)
        self.proc_var = tk.StringVar(value=self.automation.settings.get("process_name", "TslGame.exe"))
        ttk.Entry(form, textvariable=self.proc_var, width=18).grid(row=row, column=1, sticky="w", padx=8, pady=4)
        ttk.Label(form, text="(например: TslGame.exe для PUBG, оставьте пустым чтобы не ждать)", foreground="gray").grid(row=row, column=2, sticky="w")
        row += 1

        # wait_process_timeout
        ttk.Label(form, text="Макс. ожидание запуска игры (сек):").grid(row=row, column=0, sticky="w", pady=4)
        self.timeout_var = tk.IntVar(value=self.automation.settings.get("wait_process_timeout", 60))
        ttk.Spinbox(form, from_=5, to=300, textvariable=self.timeout_var, width=10).grid(row=row, column=1, sticky="w", padx=8, pady=4)
        row += 1

        ttk.Separator(form, orient="horizontal").grid(row=row, column=0, columnspan=3, sticky="ew", pady=8)
        row += 1

        # before_clicks
        ttk.Label(form, text="Пауза перед началом кликов:").grid(row=row, column=0, sticky="w", pady=4)
        self.before_clicks_var = tk.DoubleVar(value=delays.get("before_clicks", 5.0))
        ttk.Spinbox(form, from_=1.0, to=60.0, increment=0.5, textvariable=self.before_clicks_var, width=10).grid(row=row, column=1, sticky="w", padx=8, pady=4)
        ttk.Label(form, text="секунд (время на прогрузку лобби/меню)", foreground="gray").grid(row=row, column=2, sticky="w")
        row += 1

        # between_clicks
        ttk.Label(form, text="КД между кликами (задержка):").grid(row=row, column=0, sticky="w", pady=4)
        self.between_clicks_var = tk.DoubleVar(value=delays.get("between_clicks", 3.0))
        ttk.Spinbox(form, from_=0.5, to=30.0, increment=0.5, textvariable=self.between_clicks_var, width=10).grid(row=row, column=1, sticky="w", padx=8, pady=4)
        ttk.Label(form, text="секунд между каждым нажатием кнопки", foreground="gray").grid(row=row, column=2, sticky="w")
        row += 1

        # after_claiming
        ttk.Label(form, text="Пауза после сбора наград:").grid(row=row, column=0, sticky="w", pady=4)
        self.after_claiming_var = tk.DoubleVar(value=delays.get("after_claiming", 4.0))
        ttk.Spinbox(form, from_=1.0, to=60.0, increment=0.5, textvariable=self.after_claiming_var, width=10).grid(row=row, column=1, sticky="w", padx=8, pady=4)
        ttk.Label(form, text="секунд перед выходом / закрытием", foreground="gray").grid(row=row, column=2, sticky="w")
        row += 1

        # website_wait
        ttk.Label(form, text="Ожидание веб-страницы:").grid(row=row, column=0, sticky="w", pady=4)
        self.website_wait_var = tk.DoubleVar(value=delays.get("website_wait", 5.0))
        ttk.Spinbox(form, from_=1.0, to=30.0, increment=0.5, textvariable=self.website_wait_var, width=10).grid(row=row, column=1, sticky="w", padx=8, pady=4)
        row += 1

        # scroll_delay
        ttk.Label(form, text="Задержка между шагами скролла:").grid(row=row, column=0, sticky="w", pady=4)
        self.scroll_delay_var = tk.DoubleVar(value=delays.get("scroll_delay", 0.3))
        ttk.Spinbox(form, from_=0.1, to=2.0, increment=0.1, textvariable=self.scroll_delay_var, width=10).grid(row=row, column=1, sticky="w", padx=8, pady=4)
        row += 1

        # between_accounts
        ttk.Label(form, text="Пауза между аккаунтами (фарм):").grid(row=row, column=0, sticky="w", pady=4)
        self.between_accounts_var = tk.DoubleVar(value=delays.get("between_accounts", 15.0))
        ttk.Spinbox(form, from_=0.0, to=300.0, increment=1.0, textvariable=self.between_accounts_var, width=10).grid(row=row, column=1, sticky="w", padx=8, pady=4)
        row += 1

    def _save_delays_into_settings(self):
        self.automation.settings["enabled"] = self.enabled_var.get()
        self.automation.settings["process_name"] = self.proc_var.get().strip()
        self.automation.settings["wait_process_timeout"] = int(self.timeout_var.get())

        delays = self.automation.settings.setdefault("delays", {})
        delays["before_clicks"] = float(self.before_clicks_var.get())
        delays["between_clicks"] = float(self.between_clicks_var.get())
        delays["after_claiming"] = float(self.after_claiming_var.get())
        delays["website_wait"] = float(self.website_wait_var.get())
        delays["scroll_delay"] = float(self.scroll_delay_var.get())
        delays["between_accounts"] = float(self.between_accounts_var.get())

        self.automation.save_settings()

    def _save_and_close(self):
        try:
            self._save_delays_into_settings()
            if self.on_save_callback:
                self.on_save_callback()
            self.win.destroy()
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить настройки: {e}", parent=self.win)

    def _test_clicks_threaded(self):
        self._save_delays_into_settings()
        self.set_status("Тест: переключитесь на окно игры! Запуск через 3 сек...")

        def _worker():
            time.sleep(3)
            self.set_status("Тест: выполняю серию кликов...")
            self.automation.execute_sequence(log_callback=self.set_status)
            self.set_status("Тест: клики выполнены!")

        threading.Thread(target=_worker, daemon=True).start()

    def _on_close(self):
        self.automation.stop_capture()
        self.win.destroy()
