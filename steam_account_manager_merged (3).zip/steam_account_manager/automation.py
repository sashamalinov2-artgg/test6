"""Модуль автоматизации кликов, захвата координат и действий в игре / на веб-страницах.

Перенесён и улучшен из steam-account-launcher:
- Захват координат клика через горячую клавишу F1 (с защитой от зависания и выводом в GUI).
- Поддержка кликов через Windows API (SetCursorPos + mouse_event) и запасной fallback через PyAutoGUI.
- Настраиваемый список игровых кнопок и последовательность их выполнения.
- Поддержка кнопок веб-событий (по координатам или по шаблону изображения Image Template Matching).
- Настраиваемые задержки (КД между кликами, перед кликами, после сбора наград, между аккаунтами, скролл).
- Хранение всех настроек в game_automation.json.
"""

import json
import os
import time
import threading
from pathlib import Path

from logger import logger, log_exc

# Опциональный импорт графических/WinAPI библиотек с защитой от сбоя при отсутствии зависимостей
try:
    import ctypes
    HAS_CTYPES = True
except ImportError:
    HAS_CTYPES = False

try:
    import pyautogui
    pyautogui.FAILSAFE = False
    HAS_PYAUTOGUI = True
except ImportError:
    HAS_PYAUTOGUI = False

try:
    from pynput import keyboard
    HAS_PYNPUT = True
except ImportError:
    HAS_PYNPUT = False

try:
    from PIL import Image, ImageGrab
    import numpy as np
    from scipy import signal
    HAS_IMAGE_MATCH = True
except ImportError:
    HAS_IMAGE_MATCH = False

# Windows API constants
MOUSE_EVENT_MOVE = 0x0001
MOUSE_EVENT_LEFTDOWN = 0x0002
MOUSE_EVENT_LEFTUP = 0x0004


def click_at_windows_api(x, y):
    """Клик мыши через Windows API для максимальной совместимости с играми."""
    if not HAS_CTYPES:
        return False
    try:
        user32 = ctypes.windll.user32
        user32.SetCursorPos(int(x), int(y))
        time.sleep(0.08)
        user32.mouse_event(MOUSE_EVENT_LEFTDOWN, int(x), int(y), 0, 0)
        time.sleep(0.08)
        user32.mouse_event(MOUSE_EVENT_LEFTUP, int(x), int(y), 0, 0)
        time.sleep(0.2)
        return True
    except Exception as e:
        logger.debug("click_at_windows_api error: %s", e)
        return False


def get_mouse_position():
    """Получить текущие координаты курсора мыши (x, y)."""
    if HAS_PYAUTOGUI:
        try:
            return pyautogui.position()
        except Exception:
            pass
    if HAS_CTYPES:
        try:
            class POINT(ctypes.Structure):
                _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
            pt = POINT()
            ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
            return pt.x, pt.y
        except Exception:
            pass
    return 0, 0


class GameAutomation:
    """Управление автоматизацией игровых действий и кликов."""

    DEFAULT_SETTINGS = {
        "enabled": True,
        "process_name": "TslGame.exe",
        "wait_process_timeout": 60,
        "game_sequence": ["all_rewards", "event_rewards", "claim_reward"],
        "buttons": {
            "all_rewards": [750, 450],
            "event_rewards": [800, 500],
            "claim_reward": [850, 550]
        },
        "website_buttons": [],
        "website_button_settings": {},
        "delays": {
            "before_clicks": 5,
            "between_clicks": 3,
            "after_claiming": 4,
            "website_wait": 5,
            "scroll_delay": 0.3,
            "between_accounts": 15
        }
    }

    def __init__(self, config_file="game_automation.json", base_dir=None):
        if base_dir:
            self.config_path = Path(base_dir) / config_file
            self.templates_dir = Path(base_dir) / "button_templates"
        else:
            self.config_path = Path(config_file)
            self.templates_dir = Path("button_templates")

        self.templates_dir.mkdir(parents=True, exist_ok=True)
        self.settings = self.load_settings()
        self.capturing = False
        self.capture_key = None
        self.listener = None
        self._stop_requested = False

    def load_settings(self):
        """Загружает настройки из JSON или создает дефолтные."""
        data = dict(self.DEFAULT_SETTINGS)
        if self.config_path.exists():
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    if isinstance(loaded, dict):
                        # Мерджим словарь, чтобы новые ключи не терялись
                        for k, v in loaded.items():
                            if isinstance(v, dict) and k in data and isinstance(data[k], dict):
                                data[k].update(v)
                            else:
                                data[k] = v
                logger.info("Загружены настройки автоматизации: %s", self.config_path)
            except Exception as e:
                log_exc(f"Ошибка загрузки {self.config_path}, используются дефолтные", e)
        else:
            self.save_settings(data)
        return data

    def save_settings(self, settings=None):
        """Сохраняет текущие настройки в JSON."""
        if settings is not None:
            self.settings = settings
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=4, ensure_ascii=False)
            logger.info("Настройки автоматизации сохранены в %s", self.config_path)
            return True
        except Exception as e:
            log_exc(f"Ошибка сохранения {self.config_path}", e)
            return False

    def request_stop(self):
        """Сигнал остановки текущей серии кликов."""
        self._stop_requested = True
        self.stop_capture()

    def start_capture(self, button_name, on_captured_callback=None, status_callback=None):
        """Запуск слушателя F1 для захвата координат указанной кнопки."""
        if not HAS_PYNPUT:
            err = "Библиотека pynput не установлена. Введите координаты вручную."
            logger.warning(err)
            if status_callback:
                status_callback(err)
            return False

        self.stop_capture()
        self.capturing = True
        self.capture_key = button_name

        msg = f"Наведите курсор на '{button_name}' и нажмите F1..."
        logger.info(msg)
        if status_callback:
            status_callback(msg)

        def on_press(key):
            try:
                if key == keyboard.Key.f1 and self.capturing:
                    x, y = get_mouse_position()
                    self.set_coords_manual(self.capture_key, x, y)
                    self.capturing = False
                    
                    ok_msg = f"Координаты для '{self.capture_key}' успешно сохранены: ({x}, {y})"
                    logger.info(ok_msg)
                    if status_callback:
                        status_callback(ok_msg)
                    if on_captured_callback:
                        on_captured_callback(self.capture_key, x, y)
                    
                    return False  # Остановка слушателя
            except Exception as e:
                log_exc("Ошибка при захвате координат по F1", e)

        self.listener = keyboard.Listener(on_press=on_press)
        self.listener.daemon = True
        self.listener.start()
        return True

    def stop_capture(self):
        """Остановка слушателя клавиш захвата."""
        self.capturing = False
        if self.listener:
            try:
                self.listener.stop()
            except Exception:
                pass
            self.listener = None

    def set_coords_manual(self, button_name, x, y):
        """Установить координаты кнопки вручную."""
        if "buttons" not in self.settings:
            self.settings["buttons"] = {}
        self.settings["buttons"][button_name] = [int(x), int(y)]
        self.save_settings()
        return True

    def click_button(self, button_name, log_callback=None):
        """Кликнуть по указанной кнопке по её координатам."""
        coords = self.settings.get("buttons", {}).get(button_name)
        if not coords or len(coords) < 2:
            msg = f"Кнопка '{button_name}' не имеет настроенных координат"
            logger.warning(msg)
            if log_callback:
                log_callback(msg)
            return False

        x, y = coords[0], coords[1]
        if x == 0 and y == 0:
            msg = f"Координаты для '{button_name}' равны (0, 0), пропуск"
            logger.warning(msg)
            if log_callback:
                log_callback(msg)
            return False

        logger.info("Клик кнопки '%s' в точке (%d, %d)", button_name, x, y)
        if log_callback:
            log_callback(f"Клик '{button_name}' ({x}, {y})")

        # Пробуем через WinAPI
        if click_at_windows_api(x, y):
            return True

        # Fallback через PyAutoGUI
        if HAS_PYAUTOGUI:
            try:
                pyautogui.click(x, y)
                time.sleep(0.3)
                return True
            except Exception as e:
                logger.error("Ошибка клика через pyautogui: %s", e)

        return False

    def execute_sequence(self, sequence=None, log_callback=None, is_cancelled=None):
        """Выполнить последовательность кликов с учетом задержки between_clicks."""
        if sequence is None:
            sequence = self.settings.get("game_sequence", [])

        delays = self.settings.get("delays", {})
        delay_between = delays.get("between_clicks", 3)

        for btn in sequence:
            if self._stop_requested or (is_cancelled and is_cancelled()):
                logger.info("Выполнение последовательности отменено")
                return False

            self.click_button(btn, log_callback)

            for _ in range(int(delay_between * 10)):
                if self._stop_requested or (is_cancelled and is_cancelled()):
                    return False
                time.sleep(0.1)

        return True

    def scroll_page(self, scrolls=10, log_callback=None):
        """Прокрутка страницы колесиком мыши."""
        if not HAS_PYAUTOGUI:
            logger.warning("pyautogui не установлен, скролл пропущен")
            return False

        delays = self.settings.get("delays", {})
        scroll_delay = delays.get("scroll_delay", 0.3)

        msg = f"Прокрутка страницы ({scrolls} раз)..."
        logger.info(msg)
        if log_callback:
            log_callback(msg)

        try:
            for _ in range(scrolls):
                if self._stop_requested:
                    break
                pyautogui.scroll(-5)
                time.sleep(scroll_delay)
            return True
        except Exception as e:
            logger.error("Ошибка при скролле: %s", e)
            return False

    def find_button_by_image(self, button_name, log_callback=None):
        """Поиск шаблона кнопки на экране через сопоставление изображений (2D кросс-корреляция)."""
        if not HAS_IMAGE_MATCH:
            err = "Модули Pillow/numpy/scipy не установлены, поиск по картинке недоступен"
            logger.warning(err)
            if log_callback:
                log_callback(err)
            return None

        template_path = self.templates_dir / f"{button_name}.png"
        if not template_path.exists():
            msg = f"Шаблон изображения не найден: {template_path}"
            logger.warning(msg)
            if log_callback:
                log_callback(msg)
            return None

        try:
            screenshot = ImageGrab.grab()
            screenshot_array = np.array(screenshot)
            template = Image.open(template_path)
            template_array = np.array(template)

            screenshot_gray = np.mean(screenshot_array[:, :, :3], axis=2)
            template_gray = np.mean(template_array[:, :, :3], axis=2)

            result = signal.correlate2d(screenshot_gray, template_gray, mode='valid', boundary='fill', fillvalue=0)
            y, x = np.unravel_index(np.argmax(result), result.shape)

            center_x = int(x + template_array.shape[1] // 2)
            center_y = int(y + template_array.shape[0] // 2)

            msg = f"Кнопка '{button_name}' найдена по картинке в точке ({center_x}, {center_y})"
            logger.info(msg)
            if log_callback:
                log_callback(msg)

            return center_x, center_y
        except Exception as e:
            log_exc(f"Ошибка поиска изображения '{button_name}'", e)
            if log_callback:
                log_callback(f"Ошибка поиска: {e}")
            return None

    def find_and_click_website_button(self, button_name, button_settings, log_callback=None):
        """Клик по кнопке веб-события: по координатам либо по картинке."""
        method = button_settings.get("method", "coords")
        coords = None

        if method == "coords":
            c = button_settings.get("coords", [0, 0])
            if c and (c[0] != 0 or c[1] != 0):
                coords = (c[0], c[1])
        elif method == "image":
            coords = self.find_button_by_image(button_name, log_callback)

        if coords:
            if log_callback:
                log_callback(f"Веб-клик '{button_name}' ({coords[0]}, {coords[1]})")
            if click_at_windows_api(coords[0], coords[1]):
                return True
            if HAS_PYAUTOGUI:
                try:
                    pyautogui.click(coords[0], coords[1])
                    return True
                except Exception:
                    pass

        return False

    def is_process_running(self, process_name):
        """Проверить, запущен ли процесс игры в системе Windows."""
        if not process_name:
            return False
        try:
            import subprocess
            output = subprocess.check_output(
                ["tasklist", "/FI", f"IMAGENAME eq {process_name}"],
                text=True,
                creationflags=0x08000000 if os.name == 'nt' else 0,
                stderr=subprocess.DEVNULL
            )
            return process_name.lower() in output.lower()
        except Exception:
            return False

    def wait_for_game_process(self, process_name=None, timeout=60, log_callback=None, is_cancelled=None):
        """Ожидание появления процесса игры в течение таймаута."""
        if not process_name:
            process_name = self.settings.get("process_name", "TslGame.exe")

        logger.info("Ожидание запуска процесса %s (до %d сек)...", process_name, timeout)
        for i in range(timeout):
            if self._stop_requested or (is_cancelled and is_cancelled()):
                return False
            if self.is_process_running(process_name):
                logger.info("Процесс %s обнаружен!", process_name)
                if log_callback:
                    log_callback(f"Процесс {process_name} запущен")
                return True
            if log_callback and i % 5 == 0:
                log_callback(f"Ожидание игры {process_name}... ({timeout - i}с)")
            time.sleep(1)

        logger.warning("Процесс %s не был обнаружен за %d сек", process_name, timeout)
        return False

    def run_full_game_cycle(self, log_callback=None, is_cancelled=None):
        """
        Полный цикл автоматизации внутри игры:
        1. Ожидание запуска процесса игры (если указан).
        2. Пауза before_clicks.
        3. Выполнение серии кликов по игровым кнопкам (game_sequence).
        4. Если есть кнопки веб-событий — ожидание website_wait, скролл и клики.
        5. Пауза after_claiming.
        """
        self._stop_requested = False
        delays = self.settings.get("delays", {})

        # Проверка включения
        if not self.settings.get("enabled", True):
            return True

        # 1. Ожидание процесса игры (если задан)
        proc_name = self.settings.get("process_name", "").strip()
        proc_timeout = self.settings.get("wait_process_timeout", 60)
        if proc_name:
            found = self.wait_for_game_process(
                process_name=proc_name,
                timeout=proc_timeout,
                log_callback=log_callback,
                is_cancelled=is_cancelled
            )
            if not found:
                if log_callback:
                    log_callback(f"Процесс {proc_name} не обнаружен за {proc_timeout}с, но продолжаем...")
                logger.warning("Процесс %s не найден за таймаут, пробуем выполнить клики все равно", proc_name)
        else:
            if log_callback:
                log_callback("Ожидание запуска игры (10 сек)...")
            for _ in range(100):
                if self._stop_requested or (is_cancelled and is_cancelled()):
                    return False
                time.sleep(0.1)

        # 2. Пауза перед кликами
        before_clicks = delays.get("before_clicks", 5)
        if log_callback:
            log_callback(f"Ждём прогрузки меню ({before_clicks}с)...")
        for i in range(int(before_clicks * 10)):
            if self._stop_requested or (is_cancelled and is_cancelled()):
                return False
            time.sleep(0.1)

        # 3. Игровая цепочка кликов
        seq = self.settings.get("game_sequence", [])
        if seq:
            if log_callback:
                log_callback("Выполняю клики в игре...")
            ok = self.execute_sequence(seq, log_callback=log_callback, is_cancelled=is_cancelled)
            if not ok:
                return False

        # 4. Веб-события / кнопки сайта
        web_buttons = self.settings.get("website_buttons", [])
        if web_buttons:
            web_wait = delays.get("website_wait", 5)
            if log_callback:
                log_callback(f"Ожидание загрузки веб-окна ({web_wait}с)...")
            for _ in range(int(web_wait * 10)):
                if self._stop_requested or (is_cancelled and is_cancelled()):
                    return False
                time.sleep(0.1)

            self.scroll_page(scrolls=8, log_callback=log_callback)

            web_settings = self.settings.get("website_button_settings", {})
            for wb in web_buttons:
                if self._stop_requested or (is_cancelled and is_cancelled()):
                    return False
                b_cfg = web_settings.get(wb, {})
                self.find_and_click_website_button(wb, b_cfg, log_callback=log_callback)
                time.sleep(1)

        # 5. Пауза после сбора
        after_claiming = delays.get("after_claiming", 4)
        if log_callback:
            log_callback(f"Сбор завершен, ожидание {after_claiming}с...")
        for _ in range(int(after_claiming * 10)):
            if self._stop_requested or (is_cancelled and is_cancelled()):
                return False
            time.sleep(0.1)

        return True
