# Build Steam Account Switcher as a standalone .exe (Windows folder build)
# Requires: pip install pyinstaller

$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectDir

Write-Host "Installing pyinstaller if needed..." -ForegroundColor Cyan
python -m pip install pyinstaller --quiet

Write-Host "Building .exe (onedir, no console)..." -ForegroundColor Cyan
pyinstaller `
    --noconfirm `
    --noconsole `
    --name "Steam Account Switcher" `
    --icon="icon.ico" `
    --add-data "icon.ico;." `
    --hidden-import pywinauto `
    --hidden-import pywinauto.controls.uia_controls `
    --hidden-import selenium `
    --hidden-import selenium.webdriver.chrome.service `
    --hidden-import pyperclip `
    --hidden-import mafile `
    --hidden-import nebula `
    --hidden-import steam_browser `
    --hidden-import steam_client `
    main.py

Write-Host "Done. Output: dist\Steam Account Switcher\" -ForegroundColor Green
Write-Host "Run: dist\Steam Account Switcher\Steam Account Switcher.exe" -ForegroundColor Green
