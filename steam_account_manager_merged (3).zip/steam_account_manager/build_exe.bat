@echo off
chcp 65001 >nul
title Сборка Steam Account Manager в один EXE файл

echo ======================================================
echo    Сборка Steam Account Manager в .EXE
echo ======================================================
echo.

echo [1/3] Проверка и установка зависимостей...
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install pyinstaller

echo.
echo [2/3] Запуск сборки через PyInstaller...
pyinstaller --noconfirm --clean --windowed ^
    --name "Steam Account Manager" ^
    --icon "icon.ico" ^
    --add-data "icon.ico;." ^
    --hidden-import "pywinauto" ^
    --hidden-import "pywinauto.controls.uia_controls" ^
    --hidden-import "selenium" ^
    --hidden-import "selenium.webdriver.chrome.service" ^
    --hidden-import "pyperclip" ^
    --hidden-import "pyautogui" ^
    --hidden-import "pynput" ^
    --hidden-import "pynput.keyboard" ^
    --hidden-import "pynput.mouse" ^
    --hidden-import "PIL" ^
    --hidden-import "PIL.ImageGrab" ^
    --hidden-import "numpy" ^
    --hidden-import "scipy" ^
    --hidden-import "scipy.signal" ^
    --hidden-import "automation" ^
    --hidden-import "automation_gui" ^
    --hidden-import "steam_client" ^
    --hidden-import "steam_browser" ^
    --hidden-import "mafile" ^
    --hidden-import "nebula" ^
    --hidden-import "logpass_parser" ^
    main.py

echo.
if exist "dist\Steam Account Manager\Steam Account Manager.exe" (
    echo ======================================================
    echo [3/3] СБОРКА УСПЕШНО ЗАВЕРШЕНА!
    echo Готовая программа находится в папке:
    echo "dist\Steam Account Manager\Steam Account Manager.exe"
    echo ======================================================
) else (
    echo [!] Что-то пошло не так при сборке. Проверьте вывод выше.
)
pause
