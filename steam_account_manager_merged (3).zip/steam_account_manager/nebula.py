"""Интеграция с NebulaAuth: запуск приложения, автоматический клик по аккаунту,
копирование Steam Guard кода и чтение его из буфера обмена."""

import subprocess
import time
from pathlib import Path

import pyperclip

from logger import logger, log_exc


VALID_CHARS = set("23456789BCDFGHJKMNPQRTVWXY")
NEBULA_WINDOW_TITLE_RE = r"^NebulaAuth.*"


def launch_nebula(exe_path):
    path = Path(exe_path)
    if not path.exists():
        logger.error("NebulaAuth не найден: %s", exe_path)
        raise FileNotFoundError(f"NebulaAuth не найден: {exe_path}")
    logger.info("Запускаю NebulaAuth: %s", exe_path)
    subprocess.Popen([str(path)])


def _looks_like_guard_code(text):
    stripped = text.strip().upper()
    if len(stripped) != 5:
        return False
    return all(c in VALID_CHARS for c in stripped)


def get_code_from_clipboard(timeout=60):
    """Ждём пока пользователь скопирует Steam Guard код в буфер из NebulaAuth.

    Если код уже в буфере к моменту вызова — используем сразу. Иначе чистим буфер
    и ждём новое 5-символьное значение.
    """
    current = pyperclip.paste()
    if _looks_like_guard_code(current):
        logger.info("Код уже в буфере обмена: %s", current.strip().upper())
        return current.strip().upper()

    try:
        pyperclip.copy("")
        logger.info("Буфер обмена очищен, жду код...")
    except Exception as e:
        logger.warning("Не удалось очистить буфер: %s", e)

    initial = pyperclip.paste()
    deadline = time.time() + timeout

    while time.time() < deadline:
        current = pyperclip.paste()
        if current != initial and _looks_like_guard_code(current):
            logger.info("Код получен из буфера: %s", current.strip().upper())
            return current.strip().upper()
        time.sleep(0.25)

    logger.error("Код не появился в буфере за %ss", timeout)
    raise TimeoutError(
        "Steam Guard код не появился в буфере. "
        "Открой NebulaAuth и нажми на код чтобы скопировать его."
    )


def _find_nebula_window(timeout=5):
    """Возвращает окно NebulaAuth (pywinauto WindowSpecification) или None."""
    from pywinauto import Desktop  # ленивый импорт — pywinauto тяжёлый

    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            win = Desktop(backend="uia").window(title_re=NEBULA_WINDOW_TITLE_RE)
            if win.exists() and win.is_visible():
                logger.info("Окно NebulaAuth найдено: '%s'", win.window_text())
                return win
        except Exception as e:
            logger.debug("Поиск окна NebulaAuth: %s", e)
        time.sleep(0.3)
    logger.warning("Окно NebulaAuth не найдено за %ss", timeout)
    return None


def _iter_descendants(window):
    """Итератор по всем потомкам окна. Защищён от исключений pywinauto."""
    try:
        for el in window.descendants():
            yield el
    except Exception as e:
        logger.warning("Не удалось получить descendants окна: %s", e)
        return


def _element_text(el):
    """Безопасно достаёт текст элемента."""
    try:
        return (el.window_text() or "").strip()
    except Exception:
        return ""


def get_code_from_nebula(account_name, timeout=15):
    """Автоматически кликает по аккаунту в NebulaAuth и забирает код в буфер.

    account_name — логин аккаунта как он отображается в списке NebulaAuth.
    Поддерживается префиксное совпадение (NebulaAuth обрезает длинные имена).
    """
    logger.info("Ищу аккаунт '%s' в NebulaAuth", account_name)
    window = _find_nebula_window(timeout=5)
    if window is None:
        raise RuntimeError(
            "Окно NebulaAuth не найдено. Запусти NebulaAuth заранее или "
            "укажи путь к exe в настройках."
        )

    try:
        window.set_focus()
    except Exception as e:
        logger.debug("set_focus не сработал: %s", e)

    account_lc = account_name.lower()

    # 1) Ищем строку аккаунта в списке. NebulaAuth может обрезать длинные имена,
    # поэтому учитываем и обратное направление префикса.
    deadline = time.time() + timeout
    account_el = None
    while time.time() < deadline:
        for el in _iter_descendants(window):
            text = _element_text(el)
            if not text or len(text) > 80:
                continue
            tl = text.lower().rstrip(".")  # NebulaAuth добавляет "..." к обрезанным
            if tl.startswith(account_lc) or account_lc.startswith(tl):
                account_el = el
                logger.info("Аккаунт найден в списке: '%s' (текст элемента: '%s')", account_name, text)
                break
        if account_el:
            break
        time.sleep(0.3)

    if account_el is None:
        logger.error("Аккаунт '%s' не найден в списке NebulaAuth", account_name)
        raise RuntimeError(
            f"Аккаунт '{account_name}' не найден в списке NebulaAuth. "
            f"Сверь точное имя в окне NebulaAuth."
        )

    # Чистим буфер чтобы потом гарантированно прочитать свежий код
    try:
        pyperclip.copy("")
    except Exception as e:
        logger.debug("Не удалось очистить буфер перед кликом: %s", e)

    try:
        account_el.click_input()
        logger.info("Клик по аккаунту в NebulaAuth")
    except Exception as e:
        logger.error("Не удалось кликнуть по аккаунту в NebulaAuth: %s", e)
        raise RuntimeError(f"Не удалось кликнуть по аккаунту в NebulaAuth: {e}")

    # 2) Ждём пока в правой панели появится 5-символьный код
    time.sleep(0.4)
    deadline = time.time() + 8
    code_el = None
    while time.time() < deadline:
        for el in _iter_descendants(window):
            text = _element_text(el)
            stripped = text.strip().upper()
            if len(stripped) == 5 and all(c in VALID_CHARS for c in stripped):
                code_el = el
                logger.info("Код найден в UI: %s", stripped)
                break
        if code_el:
            break
        time.sleep(0.2)

    if code_el is None:
        logger.error("Код не появился в окне NebulaAuth после выбора аккаунта")
        raise RuntimeError(
            "Не нашёл Steam Guard код в окне NebulaAuth после выбора аккаунта."
        )

    # 3) Клик по коду — NebulaAuth копирует его в буфер
    try:
        code_el.click_input()
        logger.info("Клик по коду — ожидаю копирование в буфер")
    except Exception as e:
        logger.error("Не удалось кликнуть по коду в NebulaAuth: %s", e)
        raise RuntimeError(f"Не удалось кликнуть по коду в NebulaAuth: {e}")

    # 4) Читаем код из буфера (с небольшим ретраем — клик не моментальный)
    deadline = time.time() + 3
    while time.time() < deadline:
        clip = pyperclip.paste()
        stripped = (clip or "").strip().upper()
        if len(stripped) == 5 and all(c in VALID_CHARS for c in stripped):
            logger.info("Код из буфера: %s", stripped)
            return stripped
        time.sleep(0.1)

    logger.error("После клика по коду буфер не получил валидное значение: %r", pyperclip.paste())
    raise RuntimeError(
        "После клика по коду буфер не получил валидное значение. "
        f"Текущее содержимое буфера: {pyperclip.paste()!r}"
    )
