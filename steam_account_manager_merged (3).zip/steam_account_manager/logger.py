"""Централизованное логирование для Steam Account Switcher.

Логи пишутся в файл steam_switcher.log рядом с main.py и дублируются в консоль.
Уровень INFO по умолчанию; DEBUG включается через переменную окружения STEAM_SWITCHER_DEBUG=1.
"""

import logging
import os
import sys
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).parent
LOG_PATH = BASE_DIR / "steam_switcher.log"


def _get_logger():
    logger = logging.getLogger("steam_switcher")
    if logger.handlers:
        return logger

    debug = os.environ.get("STEAM_SWITCHER_DEBUG", "0") == "1"
    level = logging.DEBUG if debug else logging.INFO

    logger.setLevel(level)

    # Формат с миллисекундами и именем модуля
    fmt = logging.Formatter(
        "%(asctime)s.%(msecs)03d | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Файл (append, UTF-8)
    try:
        fh = logging.FileHandler(LOG_PATH, encoding="utf-8", mode="a")
        fh.setLevel(level)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except Exception as e:
        print(f"[logger] Не удалось открыть лог-файл {LOG_PATH}: {e}", file=sys.stderr)

    # Консоль
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    return logger


logger = _get_logger()


def log_exc(msg: str, exc: Exception):
    """Логирует исключение с полным traceback."""
    logger.exception("%s: %s", msg, exc)


def debug_dump(msg: str, data: dict = None):
    """Отладочный дамп словаря/объекта."""
    if os.environ.get("STEAM_SWITCHER_DEBUG", "0") != "1":
        return
    if data:
        logger.debug("%s: %s", msg, data)
    else:
        logger.debug(msg)
