#!/usr/bin/env python3
"""Build script for PyInstaller (cross-platform)."""

import os
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).parent
ICON = BASE / "icon.ico"

separator = ";" if os.name == "nt" else ":"
add_data = f"icon.ico{separator}."

cmd = [
    sys.executable, "-m", "PyInstaller",
    "--noconfirm",
    "--noconsole",
    "--name", "Steam Account Switcher",
    "--icon", str(ICON),
    "--add-data", add_data,
    "--hidden-import", "pywinauto",
    "--hidden-import", "pywinauto.controls.uia_controls",
    "--hidden-import", "selenium",
    "--hidden-import", "selenium.webdriver.chrome.service",
    "--hidden-import", "pyperclip",
    "--hidden-import", "mafile",
    "--hidden-import", "nebula",
    "--hidden-import", "steam_browser",
    "--hidden-import", "steam_client",
    str(BASE / "main.py"),
]

print("Running:", " ".join(cmd))
subprocess.run(cmd, check=True)
print("\nBuild complete. Check dist/Steam Account Switcher/")
