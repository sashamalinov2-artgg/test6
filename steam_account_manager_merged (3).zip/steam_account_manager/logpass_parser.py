"""Парсинг logpass.txt и импорт аккаунтов.

Формат файла (рядом с main.py):
  login:password
  login2:password2
  login3:password3

Каждый login ищется как имя файла в папке mafiles/:
  mafiles/<login>.maFile
  mafiles/<login>.mafile
"""

from pathlib import Path
from logger import logger


BASE_DIR = Path(__file__).parent
LOGPASS_PATH = BASE_DIR / "logpass.txt"
DEFAULT_MAFILES_DIR = BASE_DIR / "mafiles"


def _find_mafile_for_login(login: str, mafiles_dir: Path):
    """Ищет .maFile по логину в папке mafiles."""
    if not mafiles_dir.exists():
        return None
    candidates = [
        mafiles_dir / f"{login}.maFile",
        mafiles_dir / f"{login}.mafile",
    ]
    for c in candidates:
        if c.exists():
            try:
                rel = c.relative_to(BASE_DIR)
                return str(rel).replace("\\", "/")
            except ValueError:
                return str(c)
    return None


def parse_logpass(path: Path = None, mafiles_dir: Path = None):
    """Парсит logpass.txt и возвращает список словарей аккаунтов.

    Все аккаунты получают guard_source='mafile'.
    Пропускает пустые строки и строки без ':'.
    """
    path = path or LOGPASS_PATH
    mafiles_dir = mafiles_dir or DEFAULT_MAFILES_DIR

    if not path.exists():
        logger.error("logpass.txt не найден: %s", path)
        raise FileNotFoundError(f"logpass.txt не найден: {path}")

    lines = path.read_text(encoding="utf-8").splitlines()
    accounts = []
    for i, line in enumerate(lines, 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            logger.warning("Строка %s пропущена (нет ':'): %s", i, line[:50])
            continue
        # login:password — пароль может содержать ':'
        login, password = line.split(":", 1)
        login = login.strip()
        password = password.strip()
        if not login or not password:
            logger.warning("Строка %s пропущена (пустой логин или пароль)", i)
            continue

        mafile = _find_mafile_for_login(login, mafiles_dir)
        if mafile:
            logger.info("Для '%s' найден mafile: %s", login, mafile)
        else:
            logger.warning("Для '%s' mafile НЕ найден в %s", login, mafiles_dir)

        accounts.append({
            "label": login,
            "login": login,
            "password": password,
            "mafile": mafile,
            "guard_source": "mafile",
            "nebula_account_name": None,
            "appid": None,
        })

    logger.info("Парсинг logpass.txt завершён: %s аккаунтов", len(accounts))
    return accounts
