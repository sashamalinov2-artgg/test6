@echo off
chcp 65001 >nul
title Steam Account Manager
start "" pythonw main.py
if errorlevel 1 (
    python main.py
    pause
)
