# Launcher script

import os

def launch_steam_account(username, password):
    os.system(f'start steam://login/{username}/{password}')

# Example usage
launch_steam_account('example_user', 'example_pass')