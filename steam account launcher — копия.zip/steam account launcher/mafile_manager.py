import os
import json

class MaFileManager:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = self.load_mafile()

    def load_mafile(self):
        """
        Load the maFile (Steam Guard) data from the specified file path.
        """
        if not os.path.exists(self.file_path):
            return None
        with open(self.file_path, 'r') as file:
            return json.load(file)

    def save_mafile(self):
        """
        Save the maFile (Steam Guard) data to the specified file path.
        """
        with open(self.file_path, 'w') as file:
            json.dump(self.data, file, indent=4)

    def get_auth_code(self):
        """
        Retrieve the authentication code from the maFile data.
        """
        return self.data.get('auth_code')

    def set_auth_code(self, auth_code):
        """
        Set the authentication code in the maFile data.
        """
        self.data['auth_code'] = auth_code
        self.save_mafile()