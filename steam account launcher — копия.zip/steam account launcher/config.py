# Configuration file

STEAM_API_KEY = 'your_api_key_here'