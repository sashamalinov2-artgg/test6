# Startup Instructions for Steam Account Launcher

## Quick Start

Welcome to the Steam Account Launcher! This file serves as your entry point for quick setup and usage of the application.

### Requirements
- Ensure you have Python installed on your system.
- You may need to install any required packages. Check the `requirements.txt` file for details.

### Setting Up `logpass.txt`
1. Create a file named `logpass.txt` in the same directory as the application.
2. Inside this file, add your Steam account credentials in the following format:
   
   ```
   username=my_steam_username
   password=my_steam_password
   ```
   
3. Save the file.

### Running the Launcher
- Open your terminal or command prompt.
- Navigate to the directory where the launcher files are located.
- Run the following command to start the application:
  ```
  python launcher.py
  ```

### Notes
- Make sure your `logpass.txt` is not publicly accessible as it contains sensitive information. 
- For further configuration, please refer to the documentation in the repository.

Happy launching!