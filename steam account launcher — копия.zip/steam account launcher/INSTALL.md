# Installation Instructions and Setup Guide

## Prerequisites
Before you start the installation, make sure you have the following tools and libraries installed:
- **Node.js** (version 14 or higher)
- **npm** (Node Package Manager)

## Installation Steps
1. Clone the repository:
   ```bash
   git clone https://github.com/sashamalinov2-artgg/steam-account-launcher.git
   cd steam-account-launcher
   ```

2. Install the dependencies:
   ```bash
   npm install
   ```

3. Configure your environment variables:
   - Create a `.env` file in the root directory of the project and add your configuration settings. You can use `.env.example` as a reference.

4. Start the application:
   ```bash
   npm start
   ```

## Usage
- Once the application is running, follow the on-screen instructions to log in to your Steam account and manage your games.

## Troubleshooting
- If you encounter issues, check the logs for more information. You can also consult the [Issues section](https://github.com/sashamalinov2-artgg/steam-account-launcher/issues) of the repository for help or to report problems.
  
For more detailed information, please refer to the official documentation or the repository README.