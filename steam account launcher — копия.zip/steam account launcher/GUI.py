import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import os
import json
import subprocess
import time
import threading
import base64
import pyotp
import pyautogui
import ctypes
from pynput import keyboard
from PIL import Image, ImageGrab
import numpy as np
from scipy import signal


# Windows API constants
MOUSE_EVENT_MOVE = 0x0001
MOUSE_EVENT_LEFTDOWN = 0x0002
MOUSE_EVENT_LEFTUP = 0x0004


def click_at_windows_api(x, y):
    """Клик через Windows API"""
    try:
        user32 = ctypes.windll.user32
        user32.SetCursorPos(int(x), int(y))
        time.sleep(0.1)
        user32.mouse_event(MOUSE_EVENT_LEFTDOWN, int(x), int(y), 0, 0)
        time.sleep(0.1)
        user32.mouse_event(MOUSE_EVENT_LEFTUP, int(x), int(y), 0, 0)
        time.sleep(0.5)
        return True
    except:
        return False


class SteamAuthenticatorHelper:
    """Helper class for Steam Guard authentication with maFiles"""
    
    def __init__(self, mafiles_dir="mafiles"):
        self.mafiles_dir = mafiles_dir
        if not os.path.exists(mafiles_dir):
            os.makedirs(mafiles_dir)
    
    def get_mafile_path(self, account_login):
        if not account_login:
            return None
        
        main_path = os.path.join(self.mafiles_dir, f"{account_login}.maFile")
        if os.path.exists(main_path):
            return main_path
        
        if os.path.exists(self.mafiles_dir):
            for filename in os.listdir(self.mafiles_dir):
                filepath = os.path.join(self.mafiles_dir, filename)
                if os.path.isfile(filepath):
                    try:
                        with open(filepath, 'r') as f:
                            data = json.load(f)
                            if data.get('account_name', '').lower() == account_login.lower():
                                return filepath
                    except:
                        pass
        return None
    
    def load_mafile(self, account_login):
        if not account_login:
            return None
        
        mafile_path = self.get_mafile_path(account_login)
        if not mafile_path or not os.path.exists(mafile_path):
            return None
        
        try:
            with open(mafile_path, 'r') as f:
                return json.load(f)
        except:
            return None
    
    def generate_2fa_code(self, account_login):
        mafile = self.load_mafile(account_login)
        if not mafile or 'shared_secret' not in mafile:
            return None
        
        try:
            shared_secret = mafile['shared_secret']
            secret_bytes = base64.b64decode(shared_secret)
            totp = pyotp.TOTP(base64.b32encode(secret_bytes).decode())
            return totp.now()
        except:
            return None
    
    def has_mafile(self, account_login):
        if not account_login:
            return False
        return self.get_mafile_path(account_login) is not None
    
    @staticmethod
    def log(message):
        try:
            with open("launcher.log", "a", encoding="utf-8") as f:
                timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"[{timestamp}] {message}\n")
        except:
            pass


class AccountManager:
    def __init__(self, logpass_file="logpass.txt"):
        self.logpass_file = logpass_file
        self.accounts = []
        self.load_accounts()
    
    def load_accounts(self):
        self.accounts = []
        if not os.path.exists(self.logpass_file):
            self.create_example_file()
            return
        
        try:
            with open(self.logpass_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    parts = line.split(':')
                    if len(parts) >= 2:
                        login = parts[0].strip()
                        password = parts[1].strip()
                        nickname = parts[2].strip() if len(parts) > 2 else login
                        
                        self.accounts.append({
                            'login': login,
                            'password': password,
                            'nickname': nickname,
                            'steam_id': '',
                            'selected': False
                        })
        except:
            pass
    
    def create_example_file(self):
        example = """# Steam Account Launcher - logpass.txt
# Формат: login:password:nickname (nickname опционально)
# Пример:
# myaccount:mypassword:My Account

"""
        try:
            with open(self.logpass_file, 'w', encoding='utf-8') as f:
                f.write(example)
        except:
            pass


class GameAutomation:
    """Автоматизация игры"""
    
    def __init__(self, status_callback=None):
        self.config_file = "game_automation.json"
        self.settings = self.load_settings()
        self.status_callback = status_callback
        self.capturing = False
        self.capture_key = None
        self.listener = None
    
    def load_settings(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    return json.load(f)
            except:
                pass
        
        return {
            "game_sequence": ["all_rewards", "event_rewards", "claim_reward"],
            "buttons": {
                "all_rewards": [750, 450],
                "event_rewards": [800, 500],
                "claim_reward": [850, 550]
            },
            "website_buttons": [],
            "website_button_settings": {},
            "delays": {
                "between_clicks": 3,
                "after_claiming": 3,
                "between_accounts": 30,
                "before_clicks": 3,
                "website_wait": 5,
                "scroll_delay": 0.3
            }
        }
    
    def save_settings(self):
        try:
            with open(self.config_file, "w") as f:
                json.dump(self.settings, f, indent=4)
        except:
            pass
    
    def start_capture(self, button_name):
        if self.listener:
            try:
                self.listener.stop()
            except:
                pass
        
        self.capturing = True
        self.capture_key = button_name
        
        if self.status_callback:
            self.status_callback(f"📸 Ready to capture '{button_name}'... Press F1!")
        
        SteamAuthenticatorHelper.log(f"Waiting for F1 to capture '{button_name}'")
        
        self.listener = keyboard.Listener(on_press=self.on_key_press)
        self.listener.start()
    
    def on_key_press(self, key):
        try:
            if key == keyboard.Key.f1 and self.capturing:
                self.capture_coords(self.capture_key)
                self.capturing = False
                if self.listener:
                    self.listener.stop()
        except AttributeError:
            pass
    
    def capture_coords(self, button_name):
        try:
            x, y = pyautogui.position()
            
            if button_name not in self.settings["buttons"]:
                self.settings["buttons"][button_name] = [0, 0]
            
            self.settings["buttons"][button_name] = [x, y]
            self.save_settings()
            
            if self.status_callback:
                self.status_callback(f"✓ Captured '{button_name}' at ({x}, {y})")
            
            SteamAuthenticatorHelper.log(f"✓ Captured '{button_name}' at ({x}, {y})")
        except Exception as e:
            if self.status_callback:
                self.status_callback(f"❌ Error: {e}")
    
    def set_coords_manual(self, button_name, x, y):
        try:
            if button_name not in self.settings["buttons"]:
                self.settings["buttons"][button_name] = [0, 0]
            
            self.settings["buttons"][button_name] = [x, y]
            self.save_settings()
            
            if self.status_callback:
                self.status_callback(f"✓ Set '{button_name}' to ({x}, {y})")
            
            return True
        except:
            return False
    
    def click_button(self, button_name, log_callback=None):
        if button_name not in self.settings["buttons"]:
            return False
        
        x, y = self.settings["buttons"][button_name]
        
        if x == 0 and y == 0:
            return False
        
        SteamAuthenticatorHelper.log(f"Clicking '{button_name}' at ({x}, {y})")
        
        if click_at_windows_api(x, y):
            if log_callback:
                log_callback(f"✓ Clicked '{button_name}'")
            return True
        
        try:
            pyautogui.click(x, y)
            time.sleep(0.5)
            if log_callback:
                log_callback(f"✓ Clicked '{button_name}'")
            return True
        except:
            pass
        
        return False
    
    def execute_sequence(self, sequence, log_callback=None):
        delay_between = self.settings["delays"]["between_clicks"]
        
        for button_name in sequence:
            if not self.click_button(button_name, log_callback):
                if log_callback:
                    log_callback(f"⚠️ Could not click '{button_name}'")
            time.sleep(delay_between)
        
        return True
    
    def scroll_page(self, scrolls=10, log_callback=None):
        try:
            scroll_delay = self.settings["delays"].get("scroll_delay", 0.3)
            
            SteamAuthenticatorHelper.log(f"📜 Scrolling ({scrolls} times)...")
            if log_callback:
                log_callback(f"📜 Scrolling page...")
            
            for i in range(scrolls):
                pyautogui.scroll(-5)
                time.sleep(scroll_delay)
            
            return True
        except:
            return False
    
    def find_button_by_image(self, button_name, log_callback=None):
        """Найти кнопку по картинке"""
        template_path = f"button_templates/{button_name}.png"
        
        if not os.path.exists(template_path):
            if log_callback:
                log_callback(f"❌ Template not found: {button_name}")
            return None
        
        try:
            screenshot = ImageGrab.grab()
            screenshot_array = np.array(screenshot)
            template = Image.open(template_path)
            template_array = np.array(template)
            
            screenshot_gray = np.mean(screenshot_array[:,:,:3], axis=2)
            template_gray = np.mean(template_array[:,:,:3], axis=2)
            
            result = signal.correlate2d(screenshot_gray, template_gray, mode='valid', boundary='fill', fillvalue=0)
            
            y, x = np.unravel_index(np.argmax(result), result.shape)
            center_x = x + template_array.shape[1] // 2
            center_y = y + template_array.shape[0] // 2
            
            if log_callback:
                log_callback(f"✓ Found '{button_name}' at ({center_x}, {center_y})")
            
            return (center_x, center_y)
        except Exception as e:
            if log_callback:
                log_callback(f"❌ Error finding image: {e}")
            return None
    
    def find_and_click_website_button(self, button_settings, log_callback=None):
        """Найти и кликнуть кнопку на сайте по координатам или картинке"""
        
        method = button_settings.get("method", "coords")
        
        coords = None
        
        if method == "coords":
            coords = button_settings.get("coords", [0, 0])
            if coords[0] == 0 and coords[1] == 0:
                return False
        
        elif method == "image":
            button_name = button_settings.get("button_name", "")
            coords = self.find_button_by_image(button_name, log_callback)
            if not coords:
                return False
        
        if coords:
            if log_callback:
                log_callback(f"🌐 Clicking website button at {coords}")
            return click_at_windows_api(coords[0], coords[1])
        
        return False


class SteamLauncherGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("🎮 Steam Account Launcher - Autofarm")
        self.root.geometry("1400x950")
        
        self.current_account = None
        self.config_file = "launcher_config.json"
        self.is_launching = False
        self.is_autofarm_running = False
        self.mafile_dir = "mafiles"
        self.auth_helper = SteamAuthenticatorHelper(self.mafile_dir)
        self.account_manager = AccountManager("logpass.txt")
        self.game_automation = GameAutomation(self.update_status)
        
        self.mode = "simple"
        self.mode_var = tk.StringVar(value="simple")
        
        if not os.path.exists(self.mafile_dir):
            os.makedirs(self.mafile_dir)
        if not os.path.exists("button_templates"):
            os.makedirs("button_templates")
        
        self.load_config()
        self.create_widgets()
        self.refresh_accounts_display()
        self.log("Application started")
    
    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    self.config = json.load(f)
            except:
                self.config = self.get_default_config()
        else:
            self.config = self.get_default_config()
            self.save_config()
    
    def get_default_config(self):
        return {
            "steam_path": r"C:\Program Files (x86)\Steam",
            "steam_load_delay": 15
        }
    
    def save_config(self):
        try:
            with open(self.config_file, "w") as f:
                json.dump(self.config, f, indent=4)
        except:
            pass
    
    @staticmethod
    def log(message):
        try:
            with open("launcher.log", "a", encoding="utf-8") as f:
                timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"[{timestamp}] {message}\n")
        except:
            pass
    
    @staticmethod
    def kill_all_steam():
        os.system("taskkill /F /IM steam.exe >nul 2>&1")
        os.system("taskkill /F /IM steamwebhelper.exe >nul 2>&1")
        os.system("taskkill /F /IM TslGame.exe >nul 2>&1")
        time.sleep(1)
    
    def create_widgets(self):
        title = tk.Label(self.root, text="🎮 STEAM ACCOUNT LAUNCHER - AUTOFARM", 
                        font=("Arial", 14, "bold"), fg="#00ff00")
        title.pack(pady=10)
        
        # MODE SELECTOR
        mode_frame = ttk.Frame(self.root)
        mode_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(mode_frame, text="Mode:", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(mode_frame, text="Simple", variable=self.mode_var, value="simple",
                       command=lambda: self.switch_mode("simple")).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(mode_frame, text="Advanced", variable=self.mode_var, value="advanced",
                       command=lambda: self.switch_mode("advanced")).pack(side=tk.LEFT, padx=5)
        
        # Settings
        settings = ttk.LabelFrame(self.root, text="⚙️ Settings", padding=10)
        settings.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(settings, text="Steam Path:").grid(row=0, column=0, sticky="w", padx=5)
        self.steam_label = tk.Label(settings, text=self.config["steam_path"], fg="blue", wraplength=300)
        self.steam_label.grid(row=0, column=1, sticky="w", padx=5)
        ttk.Button(settings, text="Browse", command=self.set_steam_path).grid(row=0, column=2, padx=5)
        
        tk.Label(settings, text="Steam Load Delay (sec):").grid(row=1, column=0, sticky="w", padx=5)
        self.delay_var = tk.IntVar(value=self.config.get("steam_load_delay", 15))
        ttk.Spinbox(settings, from_=5, to=60, textvariable=self.delay_var, width=10).grid(row=1, column=1, sticky="w", padx=5)
        
        tk.Label(settings, text="maFiles Folder:").grid(row=2, column=0, sticky="w", padx=5)
        self.mafile_label = tk.Label(settings, text=self.mafile_dir, fg="green")
        self.mafile_label.grid(row=2, column=1, sticky="w", padx=5)
        ttk.Button(settings, text="Browse", command=self.set_mafiles_path).grid(row=2, column=2, padx=5)
        ttk.Button(settings, text="📂 Open", command=self.manage_mafiles).grid(row=2, column=3, padx=5)
        
        # Simple Mode Frame
        self.simple_frame = ttk.LabelFrame(self.root, text="🎮 Game Buttons", padding=10)
        self.simple_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(self.simple_frame, text="📍 All Rewards", 
                  command=lambda: self.show_coords_dialog("all_rewards")).pack(side=tk.LEFT, padx=3)
        ttk.Button(self.simple_frame, text="📍 Event Rewards", 
                  command=lambda: self.show_coords_dialog("event_rewards")).pack(side=tk.LEFT, padx=3)
        ttk.Button(self.simple_frame, text="📍 Claim Reward", 
                  command=lambda: self.show_coords_dialog("claim_reward")).pack(side=tk.LEFT, padx=3)
        
        ttk.Separator(self.simple_frame, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        
        ttk.Button(self.simple_frame, text="🎯 Capture F1", 
                  command=lambda: self.start_capture("all_rewards")).pack(side=tk.LEFT, padx=3)
        ttk.Button(self.simple_frame, text="⏱️ Delays", command=self.setup_delays).pack(side=tk.LEFT, padx=3)
        
        # Advanced Mode Frame
        self.advanced_frame = ttk.LabelFrame(self.root, text="⚙️ Advanced Settings", padding=10)
        self.advanced_frame.pack(fill=tk.X, padx=10, pady=5)
        self.advanced_frame.pack_forget()
        
        # Advanced: Game Buttons
        game_advanced = ttk.LabelFrame(self.advanced_frame, text="🎮 Game Buttons", padding=5)
        game_advanced.pack(fill=tk.X, pady=5)
        
        self.game_buttons_container = ttk.Frame(game_advanced)
        self.game_buttons_container.pack(fill=tk.X, pady=5)
        
        buttons_control = ttk.Frame(game_advanced)
        buttons_control.pack(fill=tk.X, pady=5)
        
        ttk.Button(buttons_control, text="➕ Add Button", command=self.add_game_button).pack(side=tk.LEFT, padx=3)
        ttk.Button(buttons_control, text="📋 Manage Order", command=self.manage_game_buttons).pack(side=tk.LEFT, padx=3)
        
        # Advanced: Website
        website_advanced = ttk.LabelFrame(self.advanced_frame, text="🌐 Website Buttons", padding=5)
        website_advanced.pack(fill=tk.X, pady=5)
        
        self.website_buttons_container = ttk.Frame(website_advanced)
        self.website_buttons_container.pack(fill=tk.X, pady=5)
        
        website_control = ttk.Frame(website_advanced)
        website_control.pack(fill=tk.X, pady=5)
        
        ttk.Button(website_control, text="➕ Add Button", command=self.add_website_button).pack(side=tk.LEFT, padx=3)
        ttk.Button(website_control, text="🔧 Settings", command=self.website_settings).pack(side=tk.LEFT, padx=3)
        ttk.Button(website_control, text="⏱️ Delays", command=self.setup_delays).pack(side=tk.LEFT, padx=3)
        
        # Status
        self.status_acc = tk.Label(self.root, text="No account active", 
                                  font=("Arial", 10, "bold"), fg="#ffff00")
        self.status_acc.pack(pady=5)
        
        # Accounts List
        accounts_frame = ttk.LabelFrame(self.root, text="📋 Accounts", padding=10)
        accounts_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        scrollbar = ttk.Scrollbar(accounts_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.listbox = tk.Listbox(accounts_frame, height=8, yscrollcommand=scrollbar.set, selectmode=tk.MULTIPLE)
        self.listbox.pack(fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.listbox.yview)
        
        select_frame = ttk.Frame(self.root)
        select_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(select_frame, text="☑️ Select All", command=self.select_all).pack(side=tk.LEFT, padx=3)
        ttk.Button(select_frame, text="☐ Deselect All", command=self.deselect_all).pack(side=tk.LEFT, padx=3)
        ttk.Button(select_frame, text="📝 Edit logpass.txt", command=self.edit_logpass).pack(side=tk.LEFT, padx=3)
        ttk.Button(select_frame, text="🔄 Reload", command=self.reload_accounts).pack(side=tk.LEFT, padx=3)
        
        # Main Buttons
        btn_frame = ttk.Frame(self.root)
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Button(btn_frame, text="🚀 Launch Steam", command=self.launch_steam).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="🚀➡️🎮 Steam+PUBG", command=self.launch_all).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="🤖 Autofarm Selected", command=self.autofarm_selected).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="🛑 Stop Autofarm", command=self.stop_autofarm).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="⛔ Kill All Steam", command=self.kill_all_steam_ui).pack(side=tk.LEFT, padx=3)
        
        # Status Bar
        self.status = tk.Label(self.root, text="Ready", font=("Arial", 9), fg="#00ff00")
        self.status.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=5)
        
        self.refresh_dynamic_buttons()
    
    def refresh_dynamic_buttons(self):
        """Обновить динамические кнопки"""
        # Очищаем игровые кнопки
        for widget in self.game_buttons_container.winfo_children():
            widget.destroy()
        
        game_seq = self.game_automation.settings.get("game_sequence", ["all_rewards", "event_rewards", "claim_reward"])
        for btn_name in game_seq:
            frame = ttk.Frame(self.game_buttons_container)
            frame.pack(fill=tk.X, pady=2)
            
            ttk.Button(frame, text=f"📍 {btn_name}", width=25,
                      command=lambda name=btn_name: self.show_coords_dialog(name)).pack(side=tk.LEFT, padx=3)
            
            ttk.Button(frame, text="🎯 F1", width=5,
                      command=lambda name=btn_name: self.start_capture(name)).pack(side=tk.LEFT, padx=3)
            
            coords = self.game_automation.settings["buttons"].get(btn_name, [0, 0])
            ttk.Label(frame, text=f"({coords[0]}, {coords[1]})", foreground="gray").pack(side=tk.LEFT, padx=3)
        
        # Очищаем кнопки сайта
        for widget in self.website_buttons_container.winfo_children():
            widget.destroy()
        
        website_buttons = self.game_automation.settings.get("website_buttons", [])
        for btn_name in website_buttons:
            frame = ttk.Frame(self.website_buttons_container)
            frame.pack(fill=tk.X, pady=2)
            
            btn_settings = self.game_automation.settings.get("website_button_settings", {}).get(btn_name, {})
            method = btn_settings.get("method", "coords")
            
            ttk.Button(frame, text=f"🌐 {btn_name}", width=25,
                      command=lambda name=btn_name: self.edit_website_button(name)).pack(side=tk.LEFT, padx=3)
            
            ttk.Label(frame, text=f"[{method}]", foreground="blue").pack(side=tk.LEFT, padx=3)
            
            if method == "coords":
                coords = btn_settings.get("coords", [0, 0])
                ttk.Label(frame, text=f"({coords[0]}, {coords[1]})", foreground="gray").pack(side=tk.LEFT, padx=3)
            
            ttk.Button(frame, text="❌", width=3,
                      command=lambda name=btn_name: self.remove_website_button(name)).pack(side=tk.LEFT, padx=1)
    
    def show_coords_dialog(self, button_name):
        """Диалог ввода координат"""
        current_coords = self.game_automation.settings["buttons"].get(button_name, [0, 0])
        
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Coordinates: {button_name}")
        dialog.geometry("400x200")
        
        tk.Label(dialog, text=f"Button: {button_name}", font=("Arial", 11, "bold")).pack(pady=10)
        
        tk.Label(dialog, text="X coordinate:").pack(pady=5)
        x_entry = ttk.Entry(dialog, width=20)
        x_entry.insert(0, str(current_coords[0]))
        x_entry.pack(pady=5)
        
        tk.Label(dialog, text="Y coordinate:").pack(pady=5)
        y_entry = ttk.Entry(dialog, width=20)
        y_entry.insert(0, str(current_coords[1]))
        y_entry.pack(pady=5)
        
        button_frame = ttk.Frame(dialog)
        button_frame.pack(pady=15)
        
        def save_coords():
            try:
                x = int(x_entry.get())
                y = int(y_entry.get())
                
                if self.game_automation.set_coords_manual(button_name, x, y):
                    self.refresh_dynamic_buttons()
                    dialog.destroy()
                else:
                    messagebox.showerror("Error", "Failed to save")
            except ValueError:
                messagebox.showerror("Error", "Coords must be numbers!")
        
        ttk.Button(button_frame, text="Save", command=save_coords).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT, padx=5)
    
    def add_website_button(self):
        """Добавить кнопку сайта"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Website Button")
        dialog.geometry("400x200")
        
        tk.Label(dialog, text="Button Name:").pack(pady=5)
        name_entry = ttk.Entry(dialog, width=35)
        name_entry.pack(pady=5)
        name_entry.focus()
        
        tk.Label(dialog, text="Select method:").pack(pady=5)
        
        method_var = tk.StringVar(value="coords")
        ttk.Radiobutton(dialog, text="By Coordinates (X, Y)", variable=method_var, value="coords").pack()
        ttk.Radiobutton(dialog, text="By Image", variable=method_var, value="image").pack()
        
        def save_button():
            button_name = name_entry.get().strip()
            if not button_name:
                messagebox.showerror("Error", "Button name cannot be empty!")
                return
            
            if button_name in self.game_automation.settings.get("website_buttons", []):
                messagebox.showwarning("Error", f"Button '{button_name}' already exists!")
                return
            
            method = method_var.get()
            
            # Добавляем кнопку
            if "website_buttons" not in self.game_automation.settings:
                self.game_automation.settings["website_buttons"] = []
            
            self.game_automation.settings["website_buttons"].append(button_name)
            
            # Инициализируем настройки
            if "website_button_settings" not in self.game_automation.settings:
                self.game_automation.settings["website_button_settings"] = {}
            
            self.game_automation.settings["website_button_settings"][button_name] = {
                "method": method,
                "coords": [0, 0]
            }
            
            self.game_automation.save_settings()
            self.refresh_dynamic_buttons()
            self.log(f"Added website button: {button_name} ({method})")
            
            dialog.destroy()
            
            # Показываем диалог редактирования
            self.edit_website_button(button_name)
        
        ttk.Button(dialog, text="Create", command=save_button).pack(pady=10)
    
    def edit_website_button(self, button_name):
        """Редактировать кнопку сайта"""
        btn_settings = self.game_automation.settings["website_button_settings"].get(button_name, {})
        method = btn_settings.get("method", "coords")
        
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Edit: {button_name}")
        dialog.geometry("450x300")
        
        tk.Label(dialog, text=f"Button: {button_name}", font=("Arial", 11, "bold")).pack(pady=10)
        tk.Label(dialog, text=f"Method: {method}").pack()
        
        if method == "coords":
            coords = btn_settings.get("coords", [0, 0])
            
            tk.Label(dialog, text="X coordinate:").pack(pady=5)
            x_entry = ttk.Entry(dialog, width=20)
            x_entry.insert(0, str(coords[0]))
            x_entry.pack()
            
            tk.Label(dialog, text="Y coordinate:").pack(pady=5)
            y_entry = ttk.Entry(dialog, width=20)
            y_entry.insert(0, str(coords[1]))
            y_entry.pack()
            
            def save_coords():
                try:
                    x = int(x_entry.get())
                    y = int(y_entry.get())
                    self.game_automation.settings["website_button_settings"][button_name]["coords"] = [x, y]
                    self.game_automation.save_settings()
                    self.refresh_dynamic_buttons()
                    self.log(f"Updated {button_name}: ({x}, {y})")
                    dialog.destroy()
                except ValueError:
                    messagebox.showerror("Error", "Must be numbers!")
            
            button_frame = ttk.Frame(dialog)
            button_frame.pack(pady=15)
            
            ttk.Button(button_frame, text="Save", command=save_coords).pack(side=tk.LEFT, padx=5)
            ttk.Button(button_frame, text="Capture F1", command=lambda: self.capture_website_coords(button_name, dialog)).pack(side=tk.LEFT, padx=5)
        
        elif method == "image":
            tk.Label(dialog, text="Take a screenshot of the button\nand save it to:", foreground="blue").pack(pady=10)
            tk.Label(dialog, text=f"button_templates/{button_name}.png", font=("Arial", 9, "bold")).pack(pady=5)
            
            def capture_image():
                if messagebox.askyesno("Capture", "Ready to capture? Click OK when ready, then Press F1 when on the button"):
                    self.start_capture_image(button_name)
            
            ttk.Button(dialog, text="📸 Capture Image (F1)", command=capture_image).pack(pady=10)
            ttk.Button(dialog, text="📂 Open Templates Folder", command=self.open_templates_folder).pack(pady=10)
        
        ttk.Button(dialog, text="Close", command=dialog.destroy).pack(pady=10)
    
    def capture_website_coords(self, button_name, parent_dialog):
        """Захватить координаты кнопки сайта"""
        parent_dialog.withdraw()
        self.status.config(text=f"📍 Capturing {button_name}... Press F1!")
        
        listener = keyboard.Listener(on_press=lambda key: self._on_capture_website_coords(key, button_name, parent_dialog))
        listener.start()
    
    def _on_capture_website_coords(self, key, button_name, parent_dialog):
        try:
            if key == keyboard.Key.f1:
                x, y = pyautogui.position()
                self.game_automation.settings["website_button_settings"][button_name]["coords"] = [x, y]
                self.game_automation.save_settings()
                self.refresh_dynamic_buttons()
                self.log(f"Captured {button_name}: ({x}, {y})")
                parent_dialog.deiconify()
        except:
            pass
    
    def start_capture_image(self, button_name):
        """Захватить картинку кнопки"""
        listener = keyboard.Listener(on_press=lambda key: self._on_capture_image(key, button_name))
        listener.start()
    
    def _on_capture_image(self, key, button_name):
        try:
            if key == keyboard.Key.f1:
                x, y = pyautogui.position()
                
                left = max(0, x - 60)
                top = max(0, y - 30)
                right = x + 60
                bottom = y + 30
                
                img = ImageGrab.grab(bbox=(left, top, right, bottom))
                os.makedirs("button_templates", exist_ok=True)
                img.save(f"button_templates/{button_name}.png")
                
                self.log(f"Captured image: {button_name}.png")
                self.status.config(text=f"✓ Captured image for {button_name}")
        except:
            pass
    
    def remove_website_button(self, button_name):
        """Удалить кнопку сайта"""
        if messagebox.askyesno("Remove", f"Remove '{button_name}'?"):
            self.game_automation.settings["website_buttons"].remove(button_name)
            if button_name in self.game_automation.settings.get("website_button_settings", {}):
                del self.game_automation.settings["website_button_settings"][button_name]
            self.game_automation.save_settings()
            self.refresh_dynamic_buttons()
            self.log(f"Removed website button: {button_name}")
    
    def switch_mode(self, mode):
        self.mode = mode
        
        if mode == "simple":
            self.simple_frame.pack(fill=tk.X, padx=10, pady=5)
            self.advanced_frame.pack_forget()
        else:
            self.simple_frame.pack_forget()
            self.advanced_frame.pack(fill=tk.X, padx=10, pady=5)
    
    def add_game_button(self):
        """Добавить кнопку игры"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Game Button")
        dialog.geometry("350x150")
        
        tk.Label(dialog, text="Button Name:").pack(pady=5)
        name_entry = ttk.Entry(dialog, width=35)
        name_entry.pack(pady=5)
        name_entry.focus()
        
        def save_button():
            button_name = name_entry.get().strip()
            if button_name:
                if button_name not in self.game_automation.settings["buttons"]:
                    self.game_automation.settings["buttons"][button_name] = [0, 0]
                    if button_name not in self.game_automation.settings["game_sequence"]:
                        self.game_automation.settings["game_sequence"].append(button_name)
                    self.game_automation.save_settings()
                    self.refresh_dynamic_buttons()
                    dialog.destroy()
                else:
                    messagebox.showwarning("Error", "Already exists!")
            else:
                messagebox.showerror("Error", "Name cannot be empty!")
        
        ttk.Button(dialog, text="Create", command=save_button).pack(pady=10)
    
    def manage_game_buttons(self):
        """Управлять порядком кнопок игры"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Manage Game Buttons")
        dialog.geometry("450x350")
        
        tk.Label(dialog, text="Order:", font=("Arial", 10, "bold")).pack(pady=5)
        
        listbox = tk.Listbox(dialog, selectmode=tk.SINGLE, height=12)
        listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        game_seq = self.game_automation.settings.get("game_sequence", [])
        for btn in game_seq:
            listbox.insert(tk.END, btn)
        
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)
        
        def move_up():
            sel = listbox.curselection()
            if sel and sel[0] > 0:
                idx = sel[0]
                game_seq[idx], game_seq[idx-1] = game_seq[idx-1], game_seq[idx]
                listbox.delete(0, tk.END)
                for btn in game_seq:
                    listbox.insert(tk.END, btn)
                listbox.selection_set(idx-1)
        
        def move_down():
            sel = listbox.curselection()
            if sel and sel[0] < len(game_seq)-1:
                idx = sel[0]
                game_seq[idx], game_seq[idx+1] = game_seq[idx+1], game_seq[idx]
                listbox.delete(0, tk.END)
                for btn in game_seq:
                    listbox.insert(tk.END, btn)
                listbox.selection_set(idx+1)
        
        ttk.Button(btn_frame, text="↑", command=move_up).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="↓", command=move_down).pack(side=tk.LEFT, padx=3)
        
        def save_and_close():
            self.game_automation.settings["game_sequence"] = game_seq
            self.game_automation.save_settings()
            self.refresh_dynamic_buttons()
            dialog.destroy()
        
        ttk.Button(dialog, text="Save", command=save_and_close).pack(pady=10)
    
    def website_settings(self):
        """Настройки сайта"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Website Settings")
        dialog.geometry("400x250")
        
        delays = self.game_automation.settings["delays"]
        
        tk.Label(dialog, text="Website Wait (sec):").pack(pady=5)
        website_wait = tk.IntVar(value=delays.get("website_wait", 5))
        ttk.Spinbox(dialog, from_=1, to=15, textvariable=website_wait, width=10).pack()
        
        tk.Label(dialog, text="Scroll Count:").pack(pady=5)
        scroll_count = tk.IntVar(value=10)
        ttk.Spinbox(dialog, from_=1, to=30, textvariable=scroll_count, width=10).pack()
        
        tk.Label(dialog, text="Scroll Delay (sec):").pack(pady=5)
        scroll_delay = tk.DoubleVar(value=delays.get("scroll_delay", 0.3))
        ttk.Spinbox(dialog, from_=0.1, to=2.0, textvariable=scroll_delay, width=10).pack()
        
        def save_settings():
            delays["website_wait"] = website_wait.get()
            delays["scroll_delay"] = scroll_delay.get()
            self.game_automation.save_settings()
            dialog.destroy()
        
        ttk.Button(dialog, text="Save", command=save_settings).pack(pady=10)
    
    def open_templates_folder(self):
        try:
            os.startfile("button_templates")
        except:
            pass
    
    def set_steam_path(self):
        path = filedialog.askdirectory(title="Select Steam folder")
        if path:
            self.config["steam_path"] = path
            self.steam_label.config(text=path)
            self.save_config()
    
    def set_mafiles_path(self):
        path = filedialog.askdirectory(title="Select maFiles folder")
        if path:
            self.mafile_dir = path
            self.mafile_label.config(text=path)
            self.auth_helper = SteamAuthenticatorHelper(path)
            self.refresh_accounts_display()
    
    def manage_mafiles(self):
        try:
            os.startfile(self.mafile_dir)
        except:
            pass
    
    def edit_logpass(self):
        try:
            os.startfile("logpass.txt")
        except:
            pass
    
    def reload_accounts(self):
        self.account_manager.load_accounts()
        self.refresh_accounts_display()
        self.status.config(text=f"✓ Loaded {len(self.account_manager.accounts)} accounts")
    
    def refresh_accounts_display(self):
        self.listbox.delete(0, tk.END)
        for acc in self.account_manager.accounts:
            has_mafile = "🔐" if self.auth_helper.has_mafile(acc['login']) else "❌"
            display_text = f"{acc['nickname']} ({acc['login']}) {has_mafile}"
            self.listbox.insert(tk.END, display_text)
    
    def select_all(self):
        self.listbox.select_set(0, tk.END)
    
    def deselect_all(self):
        self.listbox.select_clear(0, tk.END)
    
    def get_selected_accounts(self):
        selected_indices = self.listbox.curselection()
        return [self.account_manager.accounts[i] for i in selected_indices]
    
    def start_capture(self, button_name):
        self.status.config(text=f"📸 Press F1 on {button_name}!")
        self.game_automation.start_capture(button_name)
    
    def update_status(self, message):
        self.status.config(text=message)
        self.log(message)
    
    def setup_delays(self):
        delays = self.game_automation.settings["delays"]
        
        window = tk.Toplevel(self.root)
        window.title("⏱️ Delays")
        window.geometry("400x350")
        
        tk.Label(window, text="Before Clicks (sec):").pack(pady=5)
        before_clicks = tk.IntVar(value=delays.get("before_clicks", 3))
        ttk.Spinbox(window, from_=1, to=10, textvariable=before_clicks, width=10).pack()
        
        tk.Label(window, text="Between Clicks (sec):").pack(pady=5)
        between_clicks = tk.IntVar(value=delays["between_clicks"])
        ttk.Spinbox(window, from_=1, to=10, textvariable=between_clicks, width=10).pack()
        
        tk.Label(window, text="After Claiming (sec):").pack(pady=5)
        after_claiming = tk.IntVar(value=delays["after_claiming"])
        ttk.Spinbox(window, from_=1, to=10, textvariable=after_claiming, width=10).pack()
        
        tk.Label(window, text="Website Wait (sec):").pack(pady=5)
        website_wait = tk.IntVar(value=delays.get("website_wait", 5))
        ttk.Spinbox(window, from_=1, to=15, textvariable=website_wait, width=10).pack()
        
        tk.Label(window, text="Between Accounts (sec):").pack(pady=5)
        between_accounts = tk.IntVar(value=delays["between_accounts"])
        ttk.Spinbox(window, from_=10, to=120, textvariable=between_accounts, width=10).pack()
        
        def save_delays():
            delays["before_clicks"] = before_clicks.get()
            delays["between_clicks"] = between_clicks.get()
            delays["after_claiming"] = after_claiming.get()
            delays["website_wait"] = website_wait.get()
            delays["between_accounts"] = between_accounts.get()
            self.game_automation.save_settings()
            window.destroy()
        
        ttk.Button(window, text="Save", command=save_delays).pack(pady=10)
    
    def launch_steam(self):
        selected = self.get_selected_accounts()
        if not selected:
            return
        
        acc = selected[0]
        
        if self.is_launching:
            return
        
        if not self.auth_helper.has_mafile(acc.get('login')):
            self.log(f"ERROR: No maFile for {acc.get('login')}")
            return
        
        self.is_launching = True
        t = threading.Thread(target=self._launch_steam_thread, args=(acc,), daemon=True)
        t.start()
    
    def _launch_steam_thread(self, acc):
        try:
            self.status.config(text="⏳ Launching Steam...")
            self.kill_all_steam()
            
            steam_exe = os.path.join(self.config["steam_path"], "steam.exe")
            if not os.path.exists(steam_exe):
                return
            
            twofa_code = self.auth_helper.generate_2fa_code(acc.get('login'))
            if not twofa_code:
                return
            
            subprocess.Popen([steam_exe, "-login", acc.get('login')])
            self.current_account = acc["nickname"]
            self.status_acc.config(text=f"Active: {acc['nickname']}")
            
            delay = self.delay_var.get()
            for i in range(delay):
                self.status.config(text=f"⏳ Loading... ({delay-i}s)")
                time.sleep(1)
            
            self.status.config(text="✓ Steam ready!")
        except:
            pass
        finally:
            self.is_launching = False
    
    def launch_all(self):
        selected = self.get_selected_accounts()
        if not selected:
            return
        
        acc = selected[0]
        
        if not self.auth_helper.has_mafile(acc.get('login')):
            return
        
        if self.is_launching:
            return
        
        self.is_launching = True
        t = threading.Thread(target=self._launch_all_thread, args=(acc,), daemon=True)
        t.start()
    
    def _launch_all_thread(self, acc):
        try:
            self.kill_all_steam()
            
            steam_exe = os.path.join(self.config["steam_path"], "steam.exe")
            if not os.path.exists(steam_exe):
                return
            
            twofa_code = self.auth_helper.generate_2fa_code(acc.get('login'))
            if not twofa_code:
                return
            
            subprocess.Popen([steam_exe, "-login", acc.get('login')])
            self.current_account = acc["nickname"]
            self.status_acc.config(text=f"Active: {acc['nickname']}")
            
            delay = self.delay_var.get()
            for i in range(delay):
                self.status.config(text=f"⏳ Loading... ({delay-i}s)")
                time.sleep(1)
            
            self.status.config(text="🎮 Launching PUBG...")
            time.sleep(2)
            
            os.system("start steam://rungameid/578080")
            time.sleep(5)
            
            self.status.config(text="✓ Done!")
        except:
            pass
        finally:
            self.is_launching = False
    
    def autofarm_selected(self):
        selected = self.get_selected_accounts()
        if not selected:
            return
        
        if self.is_autofarm_running:
            return
        
        for acc in selected:
            if not self.auth_helper.has_mafile(acc.get('login')):
                return
        
        self.is_autofarm_running = True
        t = threading.Thread(target=self._autofarm_thread, args=(selected,), daemon=True)
        t.start()
    
    def _autofarm_thread(self, accounts):
        try:
            for idx, acc in enumerate(accounts, 1):
                if not self.is_autofarm_running:
                    break
                
                self.status.config(text=f"🤖 Account {idx}/{len(accounts)}")
                self.status_acc.config(text=f"Active: {acc['nickname']}")
                
                self.kill_all_steam()
                
                steam_exe = os.path.join(self.config["steam_path"], "steam.exe")
                if not os.path.exists(steam_exe):
                    break
                
                twofa_code = self.auth_helper.generate_2fa_code(acc.get('login'))
                if not twofa_code:
                    continue
                
                subprocess.Popen([steam_exe, "-login", acc.get('login')])
                
                delay = self.delay_var.get()
                for i in range(delay):
                    if not self.is_autofarm_running:
                        break
                    self.status.config(text=f"⏳ Loading... ({delay-i}s)")
                    time.sleep(1)
                
                self.status.config(text="🎮 Launching PUBG...")
                os.system("start steam://rungameid/578080")
                time.sleep(5)
                
                pubg_found = False
                for wait_count in range(60):
                    if not self.is_autofarm_running:
                        break
                    
                    pubg_process = os.popen("tasklist | find \"TslGame.exe\"").read()
                    if pubg_process:
                        pubg_found = True
                        break
                    
                    self.status.config(text=f"⏳ Waiting PUBG... ({60-wait_count}s)")
                    time.sleep(1)
                
                if not pubg_found:
                    continue
                
                time.sleep(3)
                
                # GAME
                before_clicks = self.game_automation.settings["delays"].get("before_clicks", 3)
                for i in range(before_clicks):
                    if not self.is_autofarm_running:
                        break
                    self.status.config(text=f"⏱️ Starting in {before_clicks-i}s...")
                    time.sleep(1)
                
                self.status.config(text="🤖 Clicking game buttons...")
                game_sequence = self.game_automation.settings.get("game_sequence", ["all_rewards", "event_rewards", "claim_reward"])
                self.game_automation.execute_sequence(game_sequence, self.update_status)
                
                # WEBSITE
                website_buttons = self.game_automation.settings.get("website_buttons", [])
                if website_buttons:
                    self.status.config(text="⏳ Website loading...")
                    website_wait = self.game_automation.settings["delays"].get("website_wait", 5)
                    time.sleep(website_wait)
                    
                    self.game_automation.scroll_page(scrolls=10, log_callback=self.update_status)
                    
                    self.status.config(text="🌐 Clicking website buttons...")
                    for btn_name in website_buttons:
                        btn_settings = self.game_automation.settings["website_button_settings"].get(btn_name, {})
                        self.game_automation.find_and_click_website_button(btn_settings, self.update_status)
                        time.sleep(1)
                
                # CLOSE
                after_claiming = self.game_automation.settings["delays"]["after_claiming"]
                self.status.config(text=f"⏱️ Closing in {after_claiming}s...")
                time.sleep(after_claiming)
                
                self.kill_all_steam()
                
                # NEXT
                if idx < len(accounts):
                    between_delay = self.game_automation.settings["delays"]["between_accounts"]
                    for i in range(between_delay):
                        if not self.is_autofarm_running:
                            break
                        self.status.config(text=f"⏳ Next in {between_delay-i}s...")
                        time.sleep(1)
            
            self.status.config(text="✓ Autofarm completed!")
            self.status_acc.config(text="No account active")
        except:
            pass
        finally:
            self.is_autofarm_running = False
    
    def stop_autofarm(self):
        if self.is_autofarm_running:
            self.is_autofarm_running = False
            self.status.config(text="✓ Stopped")
    
    def kill_all_steam_ui(self):
        self.kill_all_steam()
        self.status.config(text="✓ All killed!")


if __name__ == "__main__":
    root = tk.Tk()
    app = SteamLauncherGUI(root)
    root.mainloop()