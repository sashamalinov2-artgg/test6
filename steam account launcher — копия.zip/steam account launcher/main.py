import os
import json
import subprocess
import time
from pathlib import Path

class SteamAccountManager:
    def __init__(self):
        self.accounts = []
        self.current_account = None
        self.mafile_dir = "mafiles"
        self.load_accounts()
    
    def load_accounts(self):
        """Загружает аккаунты из logpass.txt"""
        if not os.path.exists("logpass.txt"):
            print("❌ Файл logpass.txt не найден!")
            return False
        
        try:
            with open("logpass.txt", "r") as f:
                for line in f:
                    line = line.strip()
                    if line and ":" in line:
                        username, password = line.split(":", 1)
                        self.accounts.append({
                            "username": username.strip(),
                            "password": password.strip(),
                            "mafile_path": os.path.join(self.mafile_dir, f"{username.strip()}.maFile")
                        })
            print(f"✅ Загружено {len(self.accounts)} аккаунтов")
            return True
        except Exception as e:
            print(f"❌ Ошибка при загрузке аккаунтов: {e}")
            return False
    
    def display_accounts(self):
        """Отображает список всех аккаунтов"""
        if not self.accounts:
            print("❌ Нет доступных аккаунтов")
            return
        
        print("
" + "="*50)
        print("📋 СПИСОК АККАУНТОВ")
        print("="*50)
        for idx, account in enumerate(self.accounts, 1):
            status = "🔄 АКТИВНЫЙ" if self.current_account == account["username"] else "⭕"
            mafile_exists = "✅" if os.path.exists(account["mafile_path"]) else "❌"
            print(f"{idx}. {account['username']} {status} | maFile: {mafile_exists}")
        print("="*50 + "\n")
    
    def get_mafile_code(self, username):
        """Получает код из maFile"""
        mafile_path = None
        for acc in self.accounts:
            if acc["username"] == username:
                mafile_path = acc["mafile_path"]
                break
        
        if not mafile_path or not os.path.exists(mafile_path):
            print(f"⚠️ maFile не найден для {username}")
            return None
        
        try:
            with open(mafile_path, "r") as f:
                data = json.load(f)
                return data.get("shared_secret", "")
        except Exception as e:
            print(f"❌ Ошибка при чтении maFile: {e}")
            return None
    
    def launch_steam_account(self, username, password):
        """Запускает Steam с указанным аккаунтом"""
        print(f"\n🚀 Запуск Steam для аккаунта: {username}")
        
        mafile_code = self.get_mafile_code(username)
        
        try:
            os.system("taskkill /F /IM steam.exe 2>nul")
            time.sleep(2)
            
            steam_path = r"C:\Program Files (x86)\Steam\steam.exe"
            
            if os.path.exists(steam_path):
                subprocess.Popen([steam_path, f"-login {username} {password}"])
                print(f"✅ Steam запущен с аккаунтом {username}")
                self.current_account = username
                
                if mafile_code:
                    print(f"📱 Код Steam Guard: {mafile_code}")
                
                return True
            else:
                print(f"❌ Steam не найден по пути: {steam_path}")
                return False
        except Exception as e:
            print(f"❌ Ошибка при запуске Steam: {e}")
            return False
    
    def launch_pubg(self):
        """Запускает PUBG через Steam"""
        if not self.current_account:
            print("❌ Сначала запустите Steam аккаунт")
            return False
        
        print(f"\n🎮 Запуск PUBG для аккаунта: {self.current_account}")
        
        try:
            os.system("start steam://rungameid/578080")
            print("✅ PUBG запущен!")
            return True
        except Exception as e:
            print(f"❌ Ошибка при запуске PUBG: {e}")
            return False
    
    def close_current_account(self):
        """Закрывает текущий аккаунт"""
        if self.current_account:
            print(f"🛑 Закрытие аккаунта: {self.current_account}")
            os.system("taskkill /F /IM steam.exe 2>nul")
            os.system("taskkill /F /IM TslGame.exe 2>nul")
            time.sleep(1)
            self.current_account = None
            print("✅ Аккаунт закрыт")
        else:
            print("⚠️ Нет активного аккаунта")
    
    def switch_account(self):
        """Автоматическое переключение на следующий аккаунт"""
        if not self.accounts:
            print("❌ Нет доступных аккаунтов")
            return
        
        current_idx = next((i for i, acc in enumerate(self.accounts) 
                           if acc["username"] == self.current_account), -1)
        next_idx = (current_idx + 1) % len(self.accounts)
        
        self.close_current_account()
        time.sleep(2)
        
        acc = self.accounts[next_idx]
        self.launch_steam_account(acc["username"], acc["password"])\n        time.sleep(5)
    
    def show_menu(self):
        """Основное меню приложения"""
        while True:
            print("\n" + "="*50)
            print("🎮 STEAM ACCOUNT LAUNCHER FOR PUBG")
            print("="*50)
            print("1. 📋 Показать все аккаунты")
            print("2. 🚀 Запустить аккаунт Steam")
            print("3. 🎮 Запустить PUBG")
            print("4. 🛑 Закрыть текущий аккаунт")
            print("5. 🔄 Переключить на следующий аккаунт")
            print("6. ❌ Выход")
            print("="*50)
            
            choice = input("\nВыберите опцию (1-6): ").strip()
            
            if choice == "1":
                self.display_accounts()
            
            elif choice == "2":
                self.display_accounts()
                try:
                    idx = int(input("Введите номер аккаунта: ")) - 1
                    if 0 <= idx < len(self.accounts):
                        acc = self.accounts[idx]
                        self.launch_steam_account(acc["username"], acc["password"])\n                        time.sleep(5)
                    else:
                        print("❌ Неверный номер")
                except ValueError:
                    print("❌ Введите число")
            
            elif choice == "3":
                self.launch_pubg()
                input("\n⏸️ Нажмите Enter когда закончите играть...")
                self.close_current_account()
            
            elif choice == "4":
                self.close_current_account()
            
            elif choice == "5":
                self.switch_account()
            
            elif choice == "6":
                print("\n👋 До свидания!")
                self.close_current_account()
                break
            
            else:
                print("❌ Неверная опция")

def main():
    print("⏳ Инициализация Steam Account Manager...")
    manager = SteamAccountManager()
    manager.show_menu()

if __name__ == "__main__":
    main()\n